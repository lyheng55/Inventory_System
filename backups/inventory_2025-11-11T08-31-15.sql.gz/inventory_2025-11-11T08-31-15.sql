/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.5.2-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: inventory_db
-- ------------------------------------------------------
-- Server version	11.5.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT 'User who performed the action (null for system actions)',
  `action` varchar(100) NOT NULL COMMENT 'Action performed (e.g., CREATE, UPDATE, DELETE, LOGIN, LOGOUT)',
  `entity` varchar(50) NOT NULL COMMENT 'Entity type (e.g., Product, User, PurchaseOrder, Stock)',
  `entity_id` int(11) DEFAULT NULL COMMENT 'ID of the affected entity',
  `changes` text DEFAULT NULL COMMENT 'JSON string of changes made (before/after values)',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IP address of the user',
  `user_agent` text DEFAULT NULL COMMENT 'User agent string from the request',
  `status` enum('success','failure','error') NOT NULL DEFAULT 'success' COMMENT 'Status of the action',
  `error_message` text DEFAULT NULL COMMENT 'Error message if action failed',
  `metadata` text DEFAULT NULL COMMENT 'Additional metadata as JSON string',
  `created_at` datetime DEFAULT NULL COMMENT 'Timestamp when the action occurred',
  PRIMARY KEY (`id`),
  KEY `idx_audit_logs_user_id` (`user_id`),
  KEY `idx_audit_logs_entity` (`entity`,`entity_id`),
  KEY `idx_audit_logs_action` (`action`),
  KEY `idx_audit_logs_created_at` (`created_at`),
  KEY `idx_audit_logs_status` (`status`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1643 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity`, `entity_id`, `changes`, `ip_address`, `user_agent`, `status`, `error_message`, `metadata`, `created_at`) VALUES (1,NULL,'LOGIN','Unknown',NULL,'{\"created\":{\"message\":\"Login successful\",\"token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMsInJvbGUiOiJhZG1pbiIsImlhdCI6MTc2MjgyNjkxMCwiZXhwIjoxNzYzNDMxNzEwfQ.VQ8lYqSNri8D7sXOxrPvMiGp2D60MQpMz0lMDed3olM\",\"user\":{\"id\":3,\"username\":\"admin\",\"email\":\"admin@example.com\",\"firstName\":\"System\",\"lastName\":\"Administrator\",\"role\":\"admin\",\"lastLogin\":\"2025-11-11T02:08:30.358Z\"}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/login\",\"statusCode\":200,\"duration\":316}','2025-11-11 02:08:30'),
(2,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":23}','2025-11-11 02:08:30'),
(3,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:08:30'),
(4,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":28}','2025-11-11 02:08:30'),
(5,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:08:30'),
(6,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:08:30'),
(7,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:08:30'),
(8,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:08:30'),
(9,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:08:30'),
(10,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:08:30'),
(11,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:08:30'),
(12,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:08:30'),
(13,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:08:31'),
(14,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:12:03'),
(15,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:12:03'),
(16,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":29}','2025-11-11 02:12:03'),
(17,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:12:03'),
(18,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:12:03'),
(19,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:12:03'),
(20,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:12:03'),
(21,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:12:03'),
(22,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:12:03'),
(23,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:12:03'),
(24,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:12:03'),
(25,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:12:03'),
(26,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:12:03'),
(27,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":18}','2025-11-11 02:17:07'),
(28,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:17:07'),
(29,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:17:07'),
(30,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:17:07'),
(31,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:17:07'),
(32,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:17:07'),
(33,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:17:07'),
(34,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:17:15'),
(35,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":23}','2025-11-11 02:17:18'),
(36,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":17}','2025-11-11 02:17:27'),
(37,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":34}','2025-11-11 02:17:30'),
(38,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:17:34'),
(39,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/auditor\",\"statusCode\":200,\"duration\":29}','2025-11-11 02:17:40'),
(40,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":46}','2025-11-11 02:17:46'),
(41,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:17:57'),
(42,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:18:00'),
(43,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:18:05'),
(44,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:18:10'),
(45,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users/stats/overview\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:18:10'),
(46,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:18:14'),
(47,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:18:14'),
(48,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:18:14'),
(49,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:18:14'),
(50,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:18:14'),
(51,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:18:14'),
(52,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":17}','2025-11-11 02:18:14'),
(53,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:18:20'),
(54,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":31}','2025-11-11 02:18:33'),
(55,NULL,'VIEW','PurchaseOrder',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/purchase-orders\",\"statusCode\":200,\"duration\":22}','2025-11-11 02:18:38'),
(56,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":17}','2025-11-11 02:18:38'),
(57,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:18:38'),
(58,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:18:38'),
(59,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:18:40'),
(60,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:18:40'),
(61,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:18:40'),
(62,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:18:40'),
(63,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:18:40'),
(64,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:18:40'),
(65,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:18:40'),
(66,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:18:42'),
(67,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:18:46'),
(68,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:18:46'),
(69,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:18:49'),
(70,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:18:49'),
(71,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:18:50'),
(72,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:18:50'),
(73,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:18:51'),
(74,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:18:51'),
(75,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:18:57'),
(76,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:19:00'),
(77,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:19:00'),
(78,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:19:01'),
(79,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:19:01'),
(80,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":25}','2025-11-11 02:19:01'),
(81,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:19:01'),
(82,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:19:01'),
(83,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:19:04'),
(84,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/auditor\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:19:06'),
(85,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/inventory_manager\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:19:10'),
(86,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:19:11'),
(87,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users/stats/overview\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:19:11'),
(88,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:19:12'),
(89,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:19:12'),
(90,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:19:12'),
(91,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:19:12'),
(92,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:19:12'),
(93,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:19:12'),
(94,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:19:12'),
(95,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:19:14'),
(96,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:19:17'),
(97,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:19:19'),
(98,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:19:21'),
(99,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/auditor\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:19:23'),
(100,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":30}','2025-11-11 02:19:25'),
(101,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":2,\"userId\":4,\"permissionId\":25,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:19:28'),
(102,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:19:28'),
(103,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":2,\"userId\":4,\"permissionId\":25,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:19:28'),
(104,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:19:28'),
(105,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":2,\"userId\":4,\"permissionId\":25,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:19:28'),
(106,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:19:28'),
(107,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:19:36'),
(108,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:19:38'),
(109,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users/stats/overview\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:19:38'),
(110,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:19:39'),
(111,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:19:39'),
(112,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','error','Failed to fetch audit statistics','{\"method\":\"GET\",\"path\":\"/api/audit-logs/stats/summary\",\"statusCode\":500,\"duration\":35}','2025-11-11 02:19:39'),
(113,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/audit-logs\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:19:39'),
(114,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','error','Failed to fetch audit statistics','{\"method\":\"GET\",\"path\":\"/api/audit-logs/stats/summary\",\"statusCode\":500,\"duration\":48}','2025-11-11 02:19:40'),
(115,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','failure','Route not found','{\"method\":\"GET\",\"path\":\"/favicon.ico\",\"statusCode\":404,\"duration\":1}','2025-11-11 02:20:08'),
(116,NULL,'LOGIN','Unknown',NULL,'{\"created\":{\"message\":\"Login successful\",\"token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMsInJvbGUiOiJhZG1pbiIsImlhdCI6MTc2MjgyNzYxMywiZXhwIjoxNzYzNDMyNDEzfQ.2jGtcuJhTqutfGGZ1m6ucxsYdJZhTn2HmpXdGwOC-10\",\"user\":{\"id\":3,\"username\":\"admin\",\"email\":\"admin@example.com\",\"firstName\":\"System\",\"lastName\":\"Administrator\",\"role\":\"admin\",\"lastLogin\":\"2025-11-11T02:20:13.058Z\"}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/login\",\"statusCode\":200,\"duration\":320}','2025-11-11 02:20:13'),
(117,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":22}','2025-11-11 02:20:13'),
(118,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:20:13'),
(119,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:20:13'),
(120,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:20:13'),
(121,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":18}','2025-11-11 02:20:13'),
(122,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:20:13'),
(123,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:20:25'),
(124,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:20:25'),
(125,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:20:25'),
(126,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:20:25'),
(127,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:20:25'),
(128,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:20:25'),
(129,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":24}','2025-11-11 02:20:25'),
(130,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:20:42'),
(131,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":3,\"userId\":3,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":23}','2025-11-11 02:20:54'),
(132,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:20:54'),
(133,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:21:19'),
(134,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":23}','2025-11-11 02:22:04'),
(135,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:22:09'),
(136,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:22:15'),
(137,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:22:15'),
(138,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:22:16'),
(139,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:22:16'),
(140,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:22:20'),
(141,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:22:20'),
(142,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:22:21'),
(143,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:22:21'),
(144,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:22:21'),
(145,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:22:21'),
(146,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:22:21'),
(147,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:22:21'),
(148,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:22:23'),
(149,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:22:23'),
(150,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":24}','2025-11-11 02:22:23'),
(151,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:22:23'),
(152,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:22:23'),
(153,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":2}','2025-11-11 02:22:23'),
(154,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:22:23'),
(155,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:22:23'),
(156,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:22:23'),
(157,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":18}','2025-11-11 02:22:23'),
(158,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:22:23'),
(159,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:22:24'),
(160,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:22:24'),
(161,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":18}','2025-11-11 02:22:24'),
(162,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:22:24'),
(163,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:22:26'),
(164,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:22:26'),
(165,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":22}','2025-11-11 02:23:40'),
(166,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":41}','2025-11-11 02:23:40'),
(167,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":40}','2025-11-11 02:23:40'),
(168,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":58}','2025-11-11 02:23:40'),
(169,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":86}','2025-11-11 02:23:40'),
(170,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":84}','2025-11-11 02:23:40'),
(171,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":31}','2025-11-11 02:23:46'),
(172,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":33}','2025-11-11 02:23:46'),
(173,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":35}','2025-11-11 02:23:46'),
(174,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":70}','2025-11-11 02:23:46'),
(175,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":61}','2025-11-11 02:23:46'),
(176,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":56}','2025-11-11 02:23:46'),
(177,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:23:54'),
(178,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:23:54'),
(179,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:23:54'),
(180,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:23:54'),
(181,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":30}','2025-11-11 02:23:54'),
(182,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":26}','2025-11-11 02:23:54'),
(183,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":28}','2025-11-11 02:23:59'),
(184,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":27}','2025-11-11 02:23:59'),
(185,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":25}','2025-11-11 02:23:59'),
(186,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":53}','2025-11-11 02:23:59'),
(187,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":40}','2025-11-11 02:23:59'),
(188,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":47}','2025-11-11 02:23:59'),
(189,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:24:15'),
(190,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:24:15'),
(191,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":23}','2025-11-11 02:24:15'),
(192,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":39}','2025-11-11 02:24:15'),
(193,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":31}','2025-11-11 02:24:15'),
(194,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":34}','2025-11-11 02:24:15'),
(195,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":35}','2025-11-11 02:24:21'),
(196,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":29}','2025-11-11 02:24:21'),
(197,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":43}','2025-11-11 02:24:21'),
(198,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":55}','2025-11-11 02:24:21'),
(199,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":74}','2025-11-11 02:24:21'),
(200,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":56}','2025-11-11 02:24:21'),
(201,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":36}','2025-11-11 02:24:35'),
(202,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":48}','2025-11-11 02:24:35'),
(203,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":25}','2025-11-11 02:24:35'),
(204,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":73}','2025-11-11 02:24:35'),
(205,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":53}','2025-11-11 02:24:35'),
(206,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":63}','2025-11-11 02:24:35'),
(207,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":41}','2025-11-11 02:24:49'),
(208,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":62}','2025-11-11 02:24:49'),
(209,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":35}','2025-11-11 02:24:49'),
(210,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":72}','2025-11-11 02:24:49'),
(211,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":90}','2025-11-11 02:24:49'),
(212,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":71}','2025-11-11 02:24:49'),
(213,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:25:05'),
(214,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:25:05'),
(215,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:25:05'),
(216,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:25:05'),
(217,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:25:05'),
(218,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:25:05'),
(219,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:25:06'),
(220,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:25:06'),
(221,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:25:06'),
(222,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:25:06'),
(223,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:25:06'),
(224,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:25:06'),
(225,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:25:06'),
(226,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:25:09'),
(227,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/auditor\",\"statusCode\":200,\"duration\":22}','2025-11-11 02:25:12'),
(228,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:25:27'),
(229,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:25:30'),
(230,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:25:30'),
(231,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:25:31'),
(232,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:25:31'),
(233,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:25:33'),
(234,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":3,\"userId\":3,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:25:36'),
(235,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:25:36'),
(236,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":3,\"userId\":3,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:25:37'),
(237,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:25:37'),
(238,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":3,\"userId\":3,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:25:37'),
(239,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:25:37'),
(240,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:25:41'),
(241,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:26:55'),
(242,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:26:55'),
(243,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":26}','2025-11-11 02:26:55'),
(244,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":25}','2025-11-11 02:26:55'),
(245,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":24}','2025-11-11 02:26:55'),
(246,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":26}','2025-11-11 02:27:01'),
(247,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":29}','2025-11-11 02:27:01'),
(248,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":30}','2025-11-11 02:27:01'),
(249,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":59}','2025-11-11 02:27:01'),
(250,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":65}','2025-11-11 02:27:01'),
(251,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":17}','2025-11-11 02:27:08'),
(252,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:27:08'),
(253,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":22}','2025-11-11 02:27:08'),
(254,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":42}','2025-11-11 02:27:08'),
(255,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":35}','2025-11-11 02:27:08'),
(256,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:27:49'),
(257,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:27:49'),
(258,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:27:49'),
(259,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:27:49'),
(260,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:27:49'),
(261,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":44}','2025-11-11 02:28:10'),
(262,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":39}','2025-11-11 02:28:10'),
(263,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":49}','2025-11-11 02:28:10'),
(264,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":74}','2025-11-11 02:28:10'),
(265,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":67}','2025-11-11 02:28:10'),
(266,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":33}','2025-11-11 02:28:28'),
(267,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":58}','2025-11-11 02:28:28'),
(268,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":34}','2025-11-11 02:28:28'),
(269,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":54}','2025-11-11 02:28:28'),
(270,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":53}','2025-11-11 02:28:28'),
(271,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":24}','2025-11-11 02:30:04'),
(272,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:30:06'),
(273,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":17}','2025-11-11 02:30:08'),
(274,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:30:08'),
(275,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:30:08'),
(276,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:30:09'),
(277,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:30:09'),
(278,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:30:09'),
(279,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:30:10'),
(280,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:30:10'),
(281,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:30:10'),
(282,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:30:14'),
(283,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":2}','2025-11-11 02:30:14'),
(284,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:30:15'),
(285,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:30:15'),
(286,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:30:15'),
(287,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:30:15'),
(288,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:30:15'),
(289,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:30:15'),
(290,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:30:15'),
(291,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:30:15'),
(292,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:30:15'),
(293,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:30:15'),
(294,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:30:15'),
(295,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:30:18'),
(296,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":2}','2025-11-11 02:30:27'),
(297,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:30:27'),
(298,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:30:27'),
(299,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:30:27'),
(300,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:30:27'),
(301,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:30:27'),
(302,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:30:27'),
(303,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:30:27'),
(304,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:30:27'),
(305,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:30:27'),
(306,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:30:27'),
(307,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:30:27'),
(308,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:30:27'),
(309,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:30:30'),
(310,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:30:31'),
(311,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:30:32'),
(312,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:30:32'),
(313,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:30:32'),
(314,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:30:32'),
(315,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:30:32'),
(316,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:30:33'),
(317,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:30:33'),
(318,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:30:33'),
(319,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:31:01'),
(320,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:31:01'),
(321,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:31:01'),
(322,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:31:01'),
(323,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:31:01'),
(324,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:31:01'),
(325,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:31:01'),
(326,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:31:01'),
(327,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:31:01'),
(328,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:31:01'),
(329,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":18}','2025-11-11 02:31:01'),
(330,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":17}','2025-11-11 02:31:01'),
(331,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:31:01'),
(332,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:31:17'),
(333,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":3,\"userId\":3,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:31:28'),
(334,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:31:28'),
(335,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:31:28'),
(336,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":3,\"userId\":3,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:31:49'),
(337,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":18}','2025-11-11 02:31:49'),
(338,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":45}','2025-11-11 02:31:49'),
(339,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:32:51'),
(340,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:32:51'),
(341,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:32:51'),
(342,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":30}','2025-11-11 02:32:51'),
(343,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":28}','2025-11-11 02:32:51'),
(344,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:32:57'),
(345,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:32:57'),
(346,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:32:57'),
(347,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":34}','2025-11-11 02:32:57'),
(348,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":27}','2025-11-11 02:32:57'),
(349,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:33:09'),
(350,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:33:09'),
(351,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:33:09'),
(352,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:33:09'),
(353,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:33:09'),
(354,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":31}','2025-11-11 02:33:21'),
(355,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":31}','2025-11-11 02:33:21'),
(356,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":29}','2025-11-11 02:33:21'),
(357,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":51}','2025-11-11 02:33:21'),
(358,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":44}','2025-11-11 02:33:21'),
(359,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:33:33'),
(360,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:33:33'),
(361,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:33:33'),
(362,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":39}','2025-11-11 02:33:33'),
(363,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":32}','2025-11-11 02:33:33'),
(364,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:33:40'),
(365,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":2}','2025-11-11 02:33:40'),
(366,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:33:40'),
(367,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:33:40'),
(368,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:33:40'),
(369,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":28}','2025-11-11 02:34:03'),
(370,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":17}','2025-11-11 02:34:03'),
(371,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":23}','2025-11-11 02:34:03'),
(372,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":39}','2025-11-11 02:34:03'),
(373,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":38}','2025-11-11 02:34:03'),
(374,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":42}','2025-11-11 02:34:28'),
(375,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":35}','2025-11-11 02:34:28'),
(376,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":32}','2025-11-11 02:34:28'),
(377,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":62}','2025-11-11 02:34:28'),
(378,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":42}','2025-11-11 02:34:28'),
(379,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:34:44'),
(380,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:34:44'),
(381,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:34:44'),
(382,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:34:44'),
(383,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:34:44'),
(384,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:34:44'),
(385,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:34:44'),
(386,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:34:44'),
(387,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:34:44'),
(388,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:34:44'),
(389,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:34:44'),
(390,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:34:44'),
(391,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:34:44'),
(392,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:34:47'),
(393,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:34:48'),
(394,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:34:48'),
(395,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:34:48'),
(396,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:34:49'),
(397,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:34:49'),
(398,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:34:49'),
(399,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:34:49'),
(400,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:34:49'),
(401,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:34:49'),
(402,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:34:50'),
(403,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:34:50'),
(404,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:34:50'),
(405,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:35:34'),
(406,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:35:34'),
(407,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:35:34'),
(408,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:35:34'),
(409,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:35:34'),
(410,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:35:34'),
(411,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:35:34'),
(412,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:35:34'),
(413,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:35:34'),
(414,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:35:34'),
(415,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:35:34'),
(416,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:35:34'),
(417,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:35:34'),
(418,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:35:48'),
(419,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":3,\"userId\":3,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:35:56'),
(420,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:35:56'),
(421,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:35:56'),
(422,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:36:33'),
(423,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:36:33'),
(424,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:36:33'),
(425,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:36:33'),
(426,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:36:33'),
(427,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":35}','2025-11-11 02:36:48'),
(428,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":33}','2025-11-11 02:36:48'),
(429,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":41}','2025-11-11 02:36:48'),
(430,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":62}','2025-11-11 02:36:48'),
(431,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":51}','2025-11-11 02:36:48'),
(432,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:37:06'),
(433,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:37:06'),
(434,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:37:06'),
(435,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:37:06'),
(436,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:37:06'),
(437,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:37:06'),
(438,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:37:07'),
(439,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:37:07'),
(440,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:37:07'),
(441,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:37:07'),
(442,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:37:07'),
(443,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:37:07'),
(444,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":35}','2025-11-11 02:37:07'),
(445,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:37:21'),
(446,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":3,\"userId\":3,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:37:29'),
(447,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:37:29'),
(448,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:37:29'),
(449,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:37:29'),
(450,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:37:29'),
(451,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:37:29'),
(452,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:38:02'),
(453,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":34}','2025-11-11 02:38:02'),
(454,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:38:02'),
(455,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:38:02'),
(456,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":18}','2025-11-11 02:38:02'),
(457,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":23}','2025-11-11 02:38:22'),
(458,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:38:22'),
(459,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:38:22'),
(460,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:38:22'),
(461,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:38:22'),
(462,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:38:22'),
(463,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:38:22'),
(464,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":18}','2025-11-11 02:38:30'),
(465,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":18}','2025-11-11 02:38:30'),
(466,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":18}','2025-11-11 02:38:30'),
(467,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":38}','2025-11-11 02:38:30'),
(468,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":17}','2025-11-11 02:38:50'),
(469,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:38:50'),
(470,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:38:50'),
(471,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:38:50'),
(472,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":46}','2025-11-11 02:39:05'),
(473,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":41}','2025-11-11 02:39:05'),
(474,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":48}','2025-11-11 02:39:05'),
(475,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":79}','2025-11-11 02:39:05'),
(476,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:39:34'),
(477,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:39:34'),
(478,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:39:34'),
(479,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:39:34'),
(480,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:39:51'),
(481,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:39:51'),
(482,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":23}','2025-11-11 02:39:52'),
(483,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:39:52'),
(484,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:39:52'),
(485,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:39:52'),
(486,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:39:52'),
(487,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:39:52'),
(488,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:39:52'),
(489,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:39:52'),
(490,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":17}','2025-11-11 02:39:52'),
(491,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:39:52'),
(492,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:39:52'),
(493,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":27}','2025-11-11 02:40:22'),
(494,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":3,\"userId\":3,\"permissionId\":14,\"canCreate\":false,\"canRead\":false,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:40:27'),
(495,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:40:27'),
(496,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:40:27'),
(497,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":3,\"userId\":3,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":17}','2025-11-11 02:40:40'),
(498,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:40:41'),
(499,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":38}','2025-11-11 02:40:41'),
(500,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":37}','2025-11-11 02:43:16'),
(501,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":33}','2025-11-11 02:43:16'),
(502,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":34}','2025-11-11 02:43:16'),
(503,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":62}','2025-11-11 02:43:16'),
(504,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":45}','2025-11-11 02:43:16'),
(505,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:43:37'),
(506,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:43:37'),
(507,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:43:37'),
(508,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:43:37'),
(509,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:43:37'),
(510,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":21}','2025-11-11 02:43:45'),
(511,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:43:45'),
(512,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:43:45'),
(513,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":43}','2025-11-11 02:43:45'),
(514,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":33}','2025-11-11 02:43:45'),
(515,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:44:08'),
(516,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:44:08'),
(517,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:44:08'),
(518,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:44:08'),
(519,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:44:08'),
(520,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:44:08'),
(521,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:44:08'),
(522,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:44:15'),
(523,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:44:15'),
(524,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:44:15'),
(525,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:44:15'),
(526,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":36}','2025-11-11 02:44:23'),
(527,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":35}','2025-11-11 02:44:23'),
(528,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":45}','2025-11-11 02:44:23'),
(529,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":73}','2025-11-11 02:44:23'),
(530,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:44:37'),
(531,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:44:37'),
(532,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:44:37'),
(533,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:44:37'),
(534,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":28}','2025-11-11 02:44:46'),
(535,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":28}','2025-11-11 02:44:46'),
(536,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":39}','2025-11-11 02:44:46'),
(537,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":71}','2025-11-11 02:44:46'),
(538,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":26}','2025-11-11 02:45:00'),
(539,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:45:00'),
(540,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:45:00'),
(541,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:45:00'),
(542,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:45:08'),
(543,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":2}','2025-11-11 02:45:08'),
(544,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":83}','2025-11-11 02:45:09'),
(545,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:45:09'),
(546,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:45:09'),
(547,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:45:09'),
(548,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:45:09'),
(549,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:45:09'),
(550,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:45:09'),
(551,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:45:09'),
(552,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:45:09'),
(553,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:45:09'),
(554,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:45:09'),
(555,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":22}','2025-11-11 02:45:28'),
(556,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:46:16'),
(557,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:46:59'),
(558,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:46:59'),
(559,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:46:59'),
(560,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:46:59'),
(561,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:46:59'),
(562,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:46:59'),
(563,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":17}','2025-11-11 02:46:59'),
(564,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:46:59'),
(565,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:46:59'),
(566,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:46:59'),
(567,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:47:00'),
(568,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:47:00'),
(569,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":20}','2025-11-11 02:47:00'),
(570,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":23}','2025-11-11 02:47:14'),
(571,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":30}','2025-11-11 02:48:04'),
(572,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":27}','2025-11-11 02:48:04'),
(573,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":24}','2025-11-11 02:48:04'),
(574,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":50}','2025-11-11 02:48:04'),
(575,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":41}','2025-11-11 02:48:04'),
(576,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:48:08'),
(577,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:48:08'),
(578,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":18}','2025-11-11 02:48:08'),
(579,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:48:08'),
(580,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:48:08'),
(581,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:48:08'),
(582,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:48:08'),
(583,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:48:08'),
(584,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:48:08'),
(585,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:48:08'),
(586,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:48:08'),
(587,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:48:08'),
(588,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:48:08'),
(589,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:49:37'),
(590,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:49:39'),
(591,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":false,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:49:41'),
(592,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:49:41'),
(593,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:49:41'),
(594,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:49:41'),
(595,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:49:41'),
(596,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:49:41'),
(597,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":false,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:49:42'),
(598,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:49:42'),
(599,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:49:42'),
(600,3,'LOGOUT','User',3,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,NULL,'2025-11-11 02:49:45'),
(601,NULL,'LOGOUT','Unknown',NULL,'{\"created\":{\"message\":\"Logout successful\",\"success\":true}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/logout\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:49:45'),
(602,NULL,'LOGIN','Unknown',NULL,'{\"created\":{\"message\":\"Login successful\",\"token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInJvbGUiOiJzYWxlc19zdGFmZiIsImlhdCI6MTc2MjgyOTM5NCwiZXhwIjoxNzYzNDM0MTk0fQ.y90cXuRiYN0gdsc8gTIT2LN-eLNvrUhHYhPfYs08qtc\",\"user\":{\"id\":4,\"username\":\"testuser\",\"email\":\"test@example.com\",\"firstName\":\"Test\",\"lastName\":\"User\",\"role\":\"sales_staff\",\"lastLogin\":\"2025-11-11T02:49:54.049Z\"}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/login\",\"statusCode\":200,\"duration\":324}','2025-11-11 02:49:54'),
(603,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:49:54'),
(604,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:49:54'),
(605,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:49:54'),
(606,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":17}','2025-11-11 02:49:54'),
(607,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/barcodes/products\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:49:57'),
(608,4,'LOGOUT','User',4,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,NULL,'2025-11-11 02:50:01'),
(609,NULL,'LOGOUT','Unknown',NULL,'{\"created\":{\"message\":\"Logout successful\",\"success\":true}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/logout\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:50:01'),
(610,NULL,'LOGIN','Unknown',NULL,'{\"created\":{\"message\":\"Login successful\",\"token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMsInJvbGUiOiJhZG1pbiIsImlhdCI6MTc2MjgyOTQwNywiZXhwIjoxNzYzNDM0MjA3fQ.RUYU9lvoBTCI9WMrCaLfZWg-41Smu55IJJHHaNJ8uvA\",\"user\":{\"id\":3,\"username\":\"admin\",\"email\":\"admin@example.com\",\"firstName\":\"System\",\"lastName\":\"Administrator\",\"role\":\"admin\",\"lastLogin\":\"2025-11-11T02:50:07.600Z\"}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/login\",\"statusCode\":200,\"duration\":298}','2025-11-11 02:50:07'),
(611,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:50:07'),
(612,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:50:07'),
(613,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:50:07'),
(614,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:50:07'),
(615,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:50:07'),
(616,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:50:07'),
(617,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:50:10'),
(618,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:50:10'),
(619,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:50:10'),
(620,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:50:10'),
(621,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:50:10'),
(622,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:50:10'),
(623,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:50:10'),
(624,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:50:12'),
(625,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:50:15'),
(626,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:50:15'),
(627,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:50:15'),
(628,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:52:00'),
(629,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:52:00'),
(630,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:52:00'),
(631,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:52:00'),
(632,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":55}','2025-11-11 02:52:01'),
(633,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":92}','2025-11-11 02:52:01'),
(634,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:52:01'),
(635,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:52:01'),
(636,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":27}','2025-11-11 02:52:08'),
(637,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":17}','2025-11-11 02:52:08'),
(638,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:52:08'),
(639,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:52:08'),
(640,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:52:08'),
(641,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:52:08'),
(642,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":2}','2025-11-11 02:52:08'),
(643,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":25}','2025-11-11 02:52:26'),
(644,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":false,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:52:29'),
(645,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:52:29'),
(646,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":36}','2025-11-11 02:52:29'),
(647,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:53:35'),
(648,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":36}','2025-11-11 02:53:35'),
(649,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":43}','2025-11-11 02:53:35'),
(650,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":89}','2025-11-11 02:53:35'),
(651,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":23}','2025-11-11 02:53:45'),
(652,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:53:45'),
(653,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:53:45'),
(654,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":52}','2025-11-11 02:54:10'),
(655,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":37}','2025-11-11 02:54:55'),
(656,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:54:58'),
(657,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":false,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:55:01'),
(658,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:55:01'),
(659,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":19}','2025-11-11 02:55:01'),
(660,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:55:02'),
(661,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":5}','2025-11-11 02:55:02'),
(662,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:55:02'),
(663,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":false,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:55:03'),
(664,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 02:55:03'),
(665,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:55:03'),
(666,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":1,\"userId\":4,\"permissionId\":14,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:55:03'),
(667,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":6}','2025-11-11 02:55:04'),
(668,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":15}','2025-11-11 02:55:04'),
(669,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":47}','2025-11-11 02:57:08'),
(670,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":43}','2025-11-11 02:57:08'),
(671,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":50}','2025-11-11 02:57:08'),
(672,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":83}','2025-11-11 02:57:08'),
(673,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":66}','2025-11-11 02:57:08'),
(674,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:57:40'),
(675,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:57:40'),
(676,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":11}','2025-11-11 02:57:40'),
(677,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":16}','2025-11-11 02:57:40'),
(678,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:57:40'),
(679,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":41}','2025-11-11 02:58:09'),
(680,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":36}','2025-11-11 02:58:09'),
(681,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":33}','2025-11-11 02:58:09'),
(682,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":75}','2025-11-11 02:58:09'),
(683,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":61}','2025-11-11 02:58:09'),
(684,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":4,\"userId\":4,\"permissionId\":17,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:58:18'),
(685,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":12}','2025-11-11 02:58:18'),
(686,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":5,\"userId\":4,\"permissionId\":15,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:58:21'),
(687,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":9}','2025-11-11 02:58:21'),
(688,3,'LOGOUT','User',3,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,NULL,'2025-11-11 02:58:25'),
(689,NULL,'LOGOUT','Unknown',NULL,'{\"created\":{\"message\":\"Logout successful\",\"success\":true}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/logout\",\"statusCode\":200,\"duration\":4}','2025-11-11 02:58:25'),
(690,NULL,'LOGIN','Unknown',NULL,'{\"created\":{\"message\":\"Login successful\",\"token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInJvbGUiOiJzYWxlc19zdGFmZiIsImlhdCI6MTc2MjgyOTkyNiwiZXhwIjoxNzYzNDM0NzI2fQ.tiKAePGsJoiZNmpvKpdl7OwZn75zuQTfjqMe6zZGlfE\",\"user\":{\"id\":4,\"username\":\"testuser\",\"email\":\"test@example.com\",\"firstName\":\"Test\",\"lastName\":\"User\",\"role\":\"sales_staff\",\"lastLogin\":\"2025-11-11T02:58:46.170Z\"}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/login\",\"statusCode\":200,\"duration\":344}','2025-11-11 02:58:46'),
(691,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:58:46'),
(692,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 02:58:46'),
(693,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 02:58:46'),
(694,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":30}','2025-11-11 02:58:46'),
(695,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":14}','2025-11-11 02:58:46'),
(696,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":22}','2025-11-11 02:58:46'),
(697,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":10}','2025-11-11 02:58:48'),
(698,4,'LOGOUT','User',4,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,NULL,'2025-11-11 02:58:51'),
(699,NULL,'LOGOUT','Unknown',NULL,'{\"created\":{\"message\":\"Logout successful\",\"success\":true}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/logout\",\"statusCode\":200,\"duration\":7}','2025-11-11 02:58:51'),
(700,NULL,'LOGIN','Unknown',NULL,'{\"created\":{\"message\":\"Login successful\",\"token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMsInJvbGUiOiJhZG1pbiIsImlhdCI6MTc2MjgzMDUwNSwiZXhwIjoxNzYzNDM1MzA1fQ.muxOgrQ7_RkMXTAvXLYIEXZiCnPB7Nx9ZI9LR73TLsA\",\"user\":{\"id\":3,\"username\":\"admin\",\"email\":\"admin@example.com\",\"firstName\":\"System\",\"lastName\":\"Administrator\",\"role\":\"admin\",\"lastLogin\":\"2025-11-11T03:08:25.058Z\"}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/login\",\"statusCode\":200,\"duration\":306}','2025-11-11 03:08:25'),
(701,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":17}','2025-11-11 03:08:25'),
(702,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":20}','2025-11-11 03:08:25'),
(703,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 03:08:25'),
(704,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 03:08:25'),
(705,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":9}','2025-11-11 03:08:25'),
(706,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":5}','2025-11-11 03:08:25'),
(707,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 03:08:27'),
(708,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 03:08:27'),
(709,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 03:08:27'),
(710,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 03:08:27'),
(711,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":15}','2025-11-11 03:08:27'),
(712,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":16}','2025-11-11 03:08:27'),
(713,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":15}','2025-11-11 03:08:27'),
(714,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/auditor\",\"statusCode\":200,\"duration\":12}','2025-11-11 03:08:30'),
(715,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/inventory_manager\",\"statusCode\":200,\"duration\":19}','2025-11-11 03:08:32'),
(716,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":8}','2025-11-11 03:08:51'),
(717,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users/stats/overview\",\"statusCode\":200,\"duration\":20}','2025-11-11 03:08:51'),
(718,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":18}','2025-11-11 06:59:29'),
(719,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":10}','2025-11-11 06:59:29'),
(720,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":29}','2025-11-11 06:59:29'),
(721,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":18}','2025-11-11 06:59:29'),
(722,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":17}','2025-11-11 06:59:29'),
(723,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 06:59:29'),
(724,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":9}','2025-11-11 06:59:29'),
(725,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":17}','2025-11-11 06:59:29'),
(726,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 06:59:35'),
(727,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":18}','2025-11-11 06:59:35'),
(728,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 06:59:35'),
(729,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 06:59:35'),
(730,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":9}','2025-11-11 06:59:35'),
(731,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":9}','2025-11-11 06:59:35'),
(732,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":15}','2025-11-11 06:59:35'),
(733,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":27}','2025-11-11 06:59:39'),
(734,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":6,\"userId\":4,\"permissionId\":20,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":16}','2025-11-11 06:59:41'),
(735,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":11}','2025-11-11 06:59:41'),
(736,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":6,\"userId\":4,\"permissionId\":20,\"canCreate\":false,\"canRead\":false,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":11}','2025-11-11 06:59:42'),
(737,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":6}','2025-11-11 06:59:42'),
(738,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/auditor\",\"statusCode\":200,\"duration\":13}','2025-11-11 06:59:45'),
(739,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":11}','2025-11-11 06:59:49'),
(740,NULL,'CREATE','Sale',NULL,'{\"created\":{\"message\":\"Permission granted to role successfully\",\"rolePermission\":{\"id\":27,\"roleId\":7,\"permissionId\":14,\"canCreate\":true,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":23}','2025-11-11 06:59:55'),
(741,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":16}','2025-11-11 06:59:55'),
(742,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":6}','2025-11-11 06:59:55'),
(743,NULL,'CREATE','Sale',NULL,'{\"created\":{\"message\":\"Permission granted to role successfully\",\"rolePermission\":{\"id\":27,\"roleId\":7,\"permissionId\":14,\"canCreate\":true,\"canRead\":false,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":24}','2025-11-11 07:00:05'),
(744,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:00:05'),
(745,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":26}','2025-11-11 07:00:05'),
(746,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','failure','Route not found','{\"method\":\"GET\",\"path\":\"/favicon.ico\",\"statusCode\":404,\"duration\":3}','2025-11-11 07:02:11'),
(747,NULL,'LOGIN','Unknown',NULL,'{\"created\":{\"message\":\"Login successful\",\"token\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMsInJvbGUiOiJhZG1pbiIsImlhdCI6MTc2Mjg0NDU4NSwiZXhwIjoxNzYzNDQ5Mzg1fQ.tDK1Joib-X_YZjRYsedpYlJYGWX0gILvgL7EgjJLs3k\",\"user\":{\"id\":3,\"username\":\"admin\",\"email\":\"admin@example.com\",\"firstName\":\"System\",\"lastName\":\"Administrator\",\"role\":\"admin\",\"lastLogin\":\"2025-11-11T07:03:05.963Z\"}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/login\",\"statusCode\":200,\"duration\":362}','2025-11-11 07:03:05'),
(748,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":39}','2025-11-11 07:03:06'),
(749,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":65}','2025-11-11 07:03:06'),
(750,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":27}','2025-11-11 07:03:06'),
(751,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":58}','2025-11-11 07:03:06'),
(752,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:03:06'),
(753,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:03:06'),
(754,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:03:06'),
(755,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:03:06'),
(756,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":28}','2025-11-11 07:03:06'),
(757,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":25}','2025-11-11 07:03:06'),
(758,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":31}','2025-11-11 07:03:06'),
(759,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":67}','2025-11-11 07:03:53'),
(760,NULL,'DELETE','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"DELETE\",\"path\":\"/api/auth/permissions/role/admin/26\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:06:38'),
(761,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:06:38'),
(762,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:06:38'),
(763,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:07:30'),
(764,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":24}','2025-11-11 07:07:31'),
(765,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:07:31'),
(766,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:07:31'),
(767,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:07:31'),
(768,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":26}','2025-11-11 07:07:31'),
(769,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:07:31'),
(770,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:07:31'),
(771,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":28}','2025-11-11 07:07:46'),
(772,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:07:46'),
(773,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:07:46'),
(774,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:07:46'),
(775,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:07:51'),
(776,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:07:51'),
(777,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":26}','2025-11-11 07:07:51'),
(778,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:07:51'),
(779,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:07:51'),
(780,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:07:51'),
(781,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:07:51'),
(782,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:07:51'),
(783,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:07:51'),
(784,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:07:51'),
(785,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:07:51'),
(786,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:07:51'),
(787,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:07:51'),
(788,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":56}','2025-11-11 07:08:02'),
(789,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"Permission granted to role successfully\",\"rolePermission\":{\"id\":23,\"roleId\":5,\"permissionId\":23,\"canCreate\":true,\"canRead\":false,\"canUpdate\":true,\"canDelete\":true}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:08:36'),
(790,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:08:36'),
(791,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:08:36'),
(792,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:08:44'),
(793,NULL,'CREATE','Sale',NULL,'{\"created\":{\"message\":\"Permission granted to role successfully\",\"rolePermission\":{\"id\":27,\"roleId\":7,\"permissionId\":14,\"canCreate\":true,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:08:48'),
(794,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:08:48'),
(795,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:08:48'),
(796,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":74}','2025-11-11 07:10:59'),
(797,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":91}','2025-11-11 07:10:59'),
(798,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":74}','2025-11-11 07:10:59'),
(799,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":121}','2025-11-11 07:10:59'),
(800,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":91}','2025-11-11 07:10:59'),
(801,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:11:10'),
(802,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:11:10'),
(803,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:11:10'),
(804,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:11:10'),
(805,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:11:10'),
(806,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:11:10'),
(807,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:11:10'),
(808,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":25}','2025-11-11 07:11:10'),
(809,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":54}','2025-11-11 07:11:10'),
(810,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":43}','2025-11-11 07:11:10'),
(811,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:11:22'),
(812,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:11:22'),
(813,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:11:22'),
(814,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:11:22'),
(815,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:11:22'),
(816,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:11:45'),
(817,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:11:45'),
(818,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:11:45'),
(819,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:11:45'),
(820,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":31}','2025-11-11 07:11:45'),
(821,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:11:45'),
(822,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:11:45'),
(823,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:11:45'),
(824,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:11:45'),
(825,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:11:45'),
(826,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:11:45'),
(827,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:11:45'),
(828,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:11:45'),
(829,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":43}','2025-11-11 07:11:49'),
(830,NULL,'CREATE','Sale',NULL,'{\"created\":{\"message\":\"Permission granted to role successfully\",\"rolePermission\":{\"id\":27,\"roleId\":7,\"permissionId\":14,\"canCreate\":true,\"canRead\":false,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:11:52'),
(831,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:11:52'),
(832,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":25}','2025-11-11 07:11:52'),
(833,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:13:57'),
(834,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:13:57'),
(835,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:13:57'),
(836,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:13:57'),
(837,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:13:57'),
(838,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:13:57'),
(839,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":35}','2025-11-11 07:13:58'),
(840,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:13:58'),
(841,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:13:58'),
(842,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:13:58'),
(843,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":24}','2025-11-11 07:13:58'),
(844,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":25}','2025-11-11 07:13:58'),
(845,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":28}','2025-11-11 07:13:58'),
(846,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":34}','2025-11-11 07:14:09'),
(847,NULL,'CREATE','Sale',NULL,'{\"created\":{\"message\":\"Permission granted to role successfully\",\"rolePermission\":{\"id\":28,\"roleId\":7,\"permissionId\":15,\"canCreate\":true,\"canRead\":true,\"canUpdate\":true,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:14:27'),
(848,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:14:27'),
(849,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:14:27'),
(850,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:15:15'),
(851,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":35}','2025-11-11 07:15:15'),
(852,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:15:15'),
(853,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:15:15'),
(854,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:15:15'),
(855,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":51}','2025-11-11 07:15:41'),
(856,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":65}','2025-11-11 07:15:41'),
(857,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":61}','2025-11-11 07:15:41'),
(858,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":102}','2025-11-11 07:15:41'),
(859,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":28}','2025-11-11 07:15:41'),
(860,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:15:47'),
(861,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:15:48'),
(862,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:15:47'),
(863,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:15:48'),
(864,NULL,'CREATE','Sale',NULL,'{\"created\":{\"message\":\"Permission granted to role successfully\",\"rolePermission\":{\"id\":28,\"roleId\":7,\"permissionId\":15,\"canCreate\":true,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:16:06'),
(865,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:16:06'),
(866,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/sales_staff\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:16:06'),
(867,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":24}','2025-11-11 07:16:25'),
(868,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":7,\"userId\":3,\"permissionId\":26,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:16:32'),
(869,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:16:32'),
(870,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":7,\"userId\":3,\"permissionId\":26,\"canCreate\":false,\"canRead\":false,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:16:36'),
(871,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:16:36'),
(872,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"User permission updated successfully\",\"userPermission\":{\"id\":7,\"userId\":3,\"permissionId\":26,\"canCreate\":false,\"canRead\":true,\"canUpdate\":false,\"canDelete\":false}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:16:37'),
(873,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:16:37'),
(874,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/4\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:16:55'),
(875,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:16:57'),
(876,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:17:18'),
(877,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:20:34'),
(878,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:20:34'),
(879,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:20:34'),
(880,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:20:34'),
(881,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:20:34'),
(882,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":24}','2025-11-11 07:20:34'),
(883,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":31}','2025-11-11 07:20:34'),
(884,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:20:34'),
(885,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:20:34'),
(886,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:20:34'),
(887,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":23}','2025-11-11 07:20:35'),
(888,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":28}','2025-11-11 07:20:35'),
(889,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:20:35'),
(890,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:21:15'),
(891,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:21:15'),
(892,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:21:16'),
(893,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":28}','2025-11-11 07:21:16'),
(894,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":26}','2025-11-11 07:21:16'),
(895,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:21:16'),
(896,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":23}','2025-11-11 07:21:16'),
(897,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:21:16'),
(898,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:21:16'),
(899,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:21:16'),
(900,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:21:16'),
(901,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:21:16'),
(902,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:21:16'),
(903,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:21:29'),
(904,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":40}','2025-11-11 07:21:29'),
(905,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:21:29'),
(906,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:21:29'),
(907,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":36}','2025-11-11 07:21:37'),
(908,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":34}','2025-11-11 07:21:37'),
(909,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":53}','2025-11-11 07:21:37'),
(910,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":85}','2025-11-11 07:21:37'),
(911,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":31}','2025-11-11 07:21:44'),
(912,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":27}','2025-11-11 07:21:44'),
(913,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:21:44'),
(914,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":79}','2025-11-11 07:21:44'),
(915,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:21:50'),
(916,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:21:50'),
(917,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:21:50'),
(918,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":40}','2025-11-11 07:21:50'),
(919,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":24}','2025-11-11 07:21:55'),
(920,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":34}','2025-11-11 07:21:55'),
(921,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":59}','2025-11-11 07:21:56'),
(922,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":66}','2025-11-11 07:21:56'),
(923,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:22:02'),
(924,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:22:02'),
(925,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:22:02'),
(926,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:22:02'),
(927,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":33}','2025-11-11 07:22:08'),
(928,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":44}','2025-11-11 07:22:08'),
(929,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":56}','2025-11-11 07:22:08'),
(930,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":46}','2025-11-11 07:22:08'),
(931,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:22:15'),
(932,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:22:15'),
(933,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:22:15'),
(934,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:22:15'),
(935,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":44}','2025-11-11 07:22:19'),
(936,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":35}','2025-11-11 07:22:19'),
(937,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":46}','2025-11-11 07:22:19'),
(938,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":67}','2025-11-11 07:22:19'),
(939,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":26}','2025-11-11 07:22:22'),
(940,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":24}','2025-11-11 07:22:22'),
(941,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:22:22'),
(942,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":48}','2025-11-11 07:22:22'),
(943,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:22:25'),
(944,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:22:25'),
(945,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:22:25'),
(946,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":30}','2025-11-11 07:22:25'),
(947,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:22:25'),
(948,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:22:25'),
(949,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:22:25'),
(950,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":39}','2025-11-11 07:22:25'),
(951,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:22:26'),
(952,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:22:26'),
(953,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:22:26'),
(954,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":34}','2025-11-11 07:22:26'),
(955,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:22:26'),
(956,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:22:26'),
(957,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:22:26'),
(958,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:22:26'),
(959,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:22:26'),
(960,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:22:26'),
(961,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:22:26'),
(962,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:22:26'),
(963,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:22:26'),
(964,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:22:26'),
(965,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:22:26'),
(966,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:22:26'),
(967,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:22:27'),
(968,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:22:27'),
(969,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":51}','2025-11-11 07:22:27'),
(970,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":123}','2025-11-11 07:22:27'),
(971,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:22:31'),
(972,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:22:31'),
(973,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":25}','2025-11-11 07:22:31'),
(974,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":52}','2025-11-11 07:22:31'),
(975,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/reports/stock\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:23:09'),
(976,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":26}','2025-11-11 07:23:09'),
(977,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:23:09'),
(978,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:23:09'),
(979,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:23:12'),
(980,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:23:12'),
(981,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:23:12'),
(982,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:23:12'),
(983,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:23:12'),
(984,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:23:12'),
(985,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:23:12'),
(986,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:23:14'),
(987,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:23:14'),
(988,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/audit-logs\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:23:14'),
(989,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','error','Failed to fetch audit statistics','{\"method\":\"GET\",\"path\":\"/api/audit-logs/stats/summary\",\"statusCode\":500,\"duration\":41}','2025-11-11 07:23:14'),
(990,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','error','Failed to fetch audit statistics','{\"method\":\"GET\",\"path\":\"/api/audit-logs/stats/summary\",\"statusCode\":500,\"duration\":52}','2025-11-11 07:23:15'),
(991,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:23:17'),
(992,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:23:17'),
(993,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:23:17'),
(994,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:23:17'),
(995,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:23:24'),
(996,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:23:24'),
(997,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/audit-logs\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:23:24'),
(998,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','error','Failed to fetch audit statistics','{\"method\":\"GET\",\"path\":\"/api/audit-logs/stats/summary\",\"statusCode\":500,\"duration\":21}','2025-11-11 07:23:24'),
(999,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','error','Failed to fetch audit statistics','{\"method\":\"GET\",\"path\":\"/api/audit-logs/stats/summary\",\"statusCode\":500,\"duration\":29}','2025-11-11 07:23:25'),
(1000,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:23:47'),
(1001,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:23:47'),
(1002,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:23:47'),
(1003,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:23:47'),
(1004,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:24:17'),
(1005,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:24:48'),
(1006,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:24:48'),
(1007,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":42}','2025-11-11 07:24:58'),
(1008,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:24:58'),
(1009,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":34}','2025-11-11 07:24:58'),
(1010,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":23}','2025-11-11 07:24:59'),
(1011,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":41}','2025-11-11 07:24:59'),
(1012,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:24:59'),
(1013,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":26}','2025-11-11 07:24:59'),
(1014,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:24:59'),
(1015,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":33}','2025-11-11 07:24:59'),
(1016,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:24:59'),
(1017,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:25:30'),
(1018,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:25:53'),
(1019,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:25:53'),
(1020,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":24}','2025-11-11 07:25:53'),
(1021,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:25:53'),
(1022,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:25:53'),
(1023,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":24}','2025-11-11 07:25:53'),
(1024,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":33}','2025-11-11 07:25:53'),
(1025,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":34}','2025-11-11 07:25:53'),
(1026,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:25:53'),
(1027,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:25:53'),
(1028,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:26:24'),
(1029,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:26:54'),
(1030,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:26:54'),
(1031,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:27:24'),
(1032,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:27:32'),
(1033,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":52}','2025-11-11 07:27:32'),
(1034,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:27:32'),
(1035,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:27:32'),
(1036,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:27:34'),
(1037,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:27:34'),
(1038,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:27:34'),
(1039,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:27:36'),
(1040,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:27:36'),
(1041,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:27:36'),
(1042,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:27:45'),
(1043,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:27:45'),
(1044,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:27:45'),
(1045,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:27:47'),
(1046,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:27:47'),
(1047,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":30}','2025-11-11 07:27:47'),
(1048,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:27:47'),
(1049,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:27:47'),
(1050,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:27:47'),
(1051,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:27:47'),
(1052,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:27:47'),
(1053,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:27:47'),
(1054,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:27:49'),
(1055,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:27:49'),
(1056,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":27}','2025-11-11 07:27:49'),
(1057,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:27:52'),
(1058,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:27:52'),
(1059,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:27:52'),
(1060,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:27:54'),
(1061,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:27:54'),
(1062,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:27:54'),
(1063,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:27:56'),
(1064,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:27:56'),
(1065,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:27:56'),
(1066,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:27:59'),
(1067,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:27:59'),
(1068,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:27:59'),
(1069,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:28:04'),
(1070,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:28:04'),
(1071,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:28:04'),
(1072,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:28:07'),
(1073,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:28:07'),
(1074,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:28:07'),
(1075,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:28:11'),
(1076,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:28:11'),
(1077,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":37}','2025-11-11 07:28:12'),
(1078,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:28:14'),
(1079,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:28:14'),
(1080,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":35}','2025-11-11 07:28:14'),
(1081,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:28:17'),
(1082,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:28:17'),
(1083,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:28:17'),
(1084,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:28:19'),
(1085,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:28:19'),
(1086,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":31}','2025-11-11 07:28:19'),
(1087,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:28:27'),
(1088,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:28:27'),
(1089,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":27}','2025-11-11 07:28:27'),
(1090,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:28:30'),
(1091,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:28:30'),
(1092,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:28:30'),
(1093,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:28:33'),
(1094,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:28:33'),
(1095,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:28:33'),
(1096,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:28:36'),
(1097,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:28:36'),
(1098,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":43}','2025-11-11 07:28:36'),
(1099,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:28:41'),
(1100,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:28:41'),
(1101,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":28}','2025-11-11 07:28:41'),
(1102,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:28:48'),
(1103,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:28:48'),
(1104,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":37}','2025-11-11 07:28:48'),
(1105,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:28:52'),
(1106,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:28:52'),
(1107,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":36}','2025-11-11 07:28:52'),
(1108,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:28:54'),
(1109,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:28:54'),
(1110,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:28:54'),
(1111,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:28:58'),
(1112,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:28:58'),
(1113,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:28:58'),
(1114,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:29:00'),
(1115,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:29:00'),
(1116,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:29:00'),
(1117,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:29:04'),
(1118,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:29:04'),
(1119,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:29:04'),
(1120,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:29:06'),
(1121,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:29:06'),
(1122,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":31}','2025-11-11 07:29:06'),
(1123,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:29:10'),
(1124,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:29:10'),
(1125,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":28}','2025-11-11 07:29:10'),
(1126,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:29:12'),
(1127,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:29:12'),
(1128,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":25}','2025-11-11 07:29:12'),
(1129,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:29:19'),
(1130,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:29:19'),
(1131,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:29:19'),
(1132,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:29:22'),
(1133,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:29:22'),
(1134,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":51}','2025-11-11 07:29:22'),
(1135,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:29:27'),
(1136,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:29:27'),
(1137,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:29:27'),
(1138,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:29:30'),
(1139,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:29:30'),
(1140,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":36}','2025-11-11 07:29:30'),
(1141,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:29:34'),
(1142,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:29:34'),
(1143,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:29:34'),
(1144,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:29:45'),
(1145,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:29:45'),
(1146,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":41}','2025-11-11 07:29:45'),
(1147,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:29:48'),
(1148,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:29:48'),
(1149,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:29:48'),
(1150,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:30:12'),
(1151,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":2}','2025-11-11 07:30:12'),
(1152,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:30:13'),
(1153,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:30:13'),
(1154,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:30:13'),
(1155,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:30:13'),
(1156,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:30:13'),
(1157,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:30:13'),
(1158,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:30:13'),
(1159,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:30:13'),
(1160,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:30:19'),
(1161,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":30}','2025-11-11 07:30:19'),
(1162,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:30:20'),
(1163,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:30:20'),
(1164,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:30:20'),
(1165,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":28}','2025-11-11 07:30:20'),
(1166,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:30:21'),
(1167,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:30:21'),
(1168,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:30:22'),
(1169,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:30:22'),
(1170,NULL,'VIEW','PurchaseOrder',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/purchase-orders\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:30:22'),
(1171,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:30:22'),
(1172,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:30:25'),
(1173,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:30:25'),
(1174,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/reports/stock\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:30:25'),
(1175,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:30:25'),
(1176,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/barcodes/products\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:30:25'),
(1177,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:30:26'),
(1178,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/search/history\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:30:28'),
(1179,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/search/filters\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:30:28'),
(1180,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:30:29'),
(1181,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:30:29'),
(1182,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:30:30'),
(1183,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:30:30'),
(1184,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:30:30'),
(1185,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:30:30'),
(1186,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/search/filters\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:30:31'),
(1187,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/search/history\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:30:31'),
(1188,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:30:49'),
(1189,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:30:49'),
(1190,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:30:51'),
(1191,NULL,'CREATE','Product',NULL,'{\"created\":{\"message\":\"Product created successfully\",\"product\":{\"isActive\":true,\"id\":1,\"sku\":\"PROD-SKU-000001\",\"name\":\"Love Story\",\"description\":\"sample\",\"categoryId\":4,\"unitPrice\":10,\"costPrice\":1000,\"unit\":\"pcs\",\"minStockLevel\":999,\"maxStockLevel\":10000,\"reorderPoint\":9,\"isPerishable\":false,\"updatedAt\":\"2025-11-11T07:32:03.901Z\",\"createdAt\":\"2025-11-11T07:32:03.901Z\"}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/products\",\"statusCode\":201,\"duration\":25}','2025-11-11 07:32:03'),
(1192,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:32:03'),
(1193,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:32:18'),
(1194,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:32:18'),
(1195,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:32:18'),
(1196,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:32:18'),
(1197,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:32:20'),
(1198,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:32:20'),
(1199,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":30}','2025-11-11 07:32:20'),
(1200,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":28}','2025-11-11 07:32:20'),
(1201,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/barcodes/products\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:32:21'),
(1202,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:32:22'),
(1203,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/sales/products/available\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:32:25'),
(1204,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/sales\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:32:27'),
(1205,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:32:54'),
(1206,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:32:54'),
(1207,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":43}','2025-11-11 07:32:54'),
(1208,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":33}','2025-11-11 07:32:54'),
(1209,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:32:54'),
(1210,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":57}','2025-11-11 07:32:54'),
(1211,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":40}','2025-11-11 07:32:55'),
(1212,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:32:55'),
(1213,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:32:55'),
(1214,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":27}','2025-11-11 07:32:55'),
(1215,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:32:57'),
(1216,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":31}','2025-11-11 07:32:58'),
(1217,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":30}','2025-11-11 07:32:58'),
(1218,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:32:58'),
(1219,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":49}','2025-11-11 07:32:58'),
(1220,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:33:02'),
(1221,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:33:02'),
(1222,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:33:02'),
(1223,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:33:03'),
(1224,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:33:04'),
(1225,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":38}','2025-11-11 07:33:05'),
(1226,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:33:05'),
(1227,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":98}','2025-11-11 07:33:05'),
(1228,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":193}','2025-11-11 07:33:05'),
(1229,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:33:24'),
(1230,NULL,'VIEW','PurchaseOrder',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/purchase-orders\",\"statusCode\":200,\"duration\":25}','2025-11-11 07:33:24'),
(1231,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":31}','2025-11-11 07:33:24'),
(1232,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:33:24'),
(1233,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":34}','2025-11-11 07:33:24'),
(1234,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:33:25'),
(1235,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/sales/products/available\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:33:27'),
(1236,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/sales\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:33:29'),
(1237,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:33:30'),
(1238,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":28}','2025-11-11 07:33:30'),
(1239,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":37}','2025-11-11 07:33:31'),
(1240,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":42}','2025-11-11 07:33:31'),
(1241,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":27}','2025-11-11 07:33:31'),
(1242,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":51}','2025-11-11 07:33:31'),
(1243,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:33:33'),
(1244,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:33:33'),
(1245,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:33:34'),
(1246,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":34}','2025-11-11 07:33:34'),
(1247,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":48}','2025-11-11 07:33:34'),
(1248,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":58}','2025-11-11 07:33:34'),
(1249,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:33:34'),
(1250,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:33:34'),
(1251,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:33:34'),
(1252,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":31}','2025-11-11 07:33:34'),
(1253,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":41}','2025-11-11 07:33:53'),
(1254,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:33:53'),
(1255,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:33:53'),
(1256,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":147}','2025-11-11 07:33:53'),
(1257,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:33:55'),
(1258,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:33:56'),
(1259,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:33:57'),
(1260,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":31}','2025-11-11 07:33:57'),
(1261,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:33:57'),
(1262,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:33:57'),
(1263,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":33}','2025-11-11 07:34:12'),
(1264,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":45}','2025-11-11 07:34:12'),
(1265,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:34:12'),
(1266,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:34:12'),
(1267,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":58}','2025-11-11 07:34:23'),
(1268,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":76}','2025-11-11 07:34:23'),
(1269,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:34:23'),
(1270,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":24}','2025-11-11 07:34:23'),
(1271,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":33}','2025-11-11 07:34:23'),
(1272,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":56}','2025-11-11 07:34:23'),
(1273,NULL,'CREATE','Stock',NULL,'{\"created\":{\"message\":\"Stock adjusted successfully\",\"stock\":{\"availableQuantity\":10,\"id\":1,\"productId\":1,\"warehouseId\":1,\"quantity\":10,\"reservedQuantity\":0,\"location\":\"PP\",\"expiryDate\":null,\"batchNumber\":null,\"createdAt\":\"2025-11-11T07:34:37.000Z\",\"updatedAt\":\"2025-11-11T07:34:37.000Z\"}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/stock/adjust\",\"statusCode\":200,\"duration\":36}','2025-11-11 07:34:37'),
(1274,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:34:38'),
(1275,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":30}','2025-11-11 07:34:38'),
(1276,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:34:41'),
(1277,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:34:41'),
(1278,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:34:42'),
(1279,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:34:42'),
(1280,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:34:42'),
(1281,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":28}','2025-11-11 07:34:42'),
(1282,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:34:46'),
(1283,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:34:46'),
(1284,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":37}','2025-11-11 07:35:00'),
(1285,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":31}','2025-11-11 07:35:00'),
(1286,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":40}','2025-11-11 07:35:00'),
(1287,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":50}','2025-11-11 07:35:00'),
(1288,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:35:00'),
(1289,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:35:00'),
(1290,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:35:01'),
(1291,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/search/history\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:35:03'),
(1292,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/search/filters\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:35:03'),
(1293,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:35:04'),
(1294,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:35:04'),
(1295,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:35:06'),
(1296,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:35:06'),
(1297,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:35:06'),
(1298,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":37}','2025-11-11 07:35:06'),
(1299,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:35:07'),
(1300,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:35:08'),
(1301,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:35:08'),
(1302,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:35:08'),
(1303,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:35:08'),
(1304,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:35:09'),
(1305,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:35:09'),
(1306,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/barcodes/products\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:35:17'),
(1307,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:35:18'),
(1308,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:35:18'),
(1309,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/audit-logs\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:35:18'),
(1310,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','error','Failed to fetch audit statistics','{\"method\":\"GET\",\"path\":\"/api/audit-logs/stats/summary\",\"statusCode\":500,\"duration\":33}','2025-11-11 07:35:18'),
(1311,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:35:19'),
(1312,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:35:19'),
(1313,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:35:19'),
(1314,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:35:19'),
(1315,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:35:19'),
(1316,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:35:19'),
(1317,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:35:19'),
(1318,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:35:24'),
(1319,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:35:26'),
(1320,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:35:26'),
(1321,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','error','Failed to fetch audit statistics','{\"method\":\"GET\",\"path\":\"/api/audit-logs/stats/summary\",\"statusCode\":500,\"duration\":19}','2025-11-11 07:35:26'),
(1322,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/audit-logs\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:35:26'),
(1323,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:35:27'),
(1324,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:35:27'),
(1325,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:35:27'),
(1326,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:35:27'),
(1327,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:35:27'),
(1328,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:35:27'),
(1329,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:35:27'),
(1330,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:35:30'),
(1331,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users/stats/overview\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:35:30'),
(1332,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:35:33'),
(1333,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/sales\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:35:34'),
(1334,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/sales/products/available\",\"statusCode\":200,\"duration\":34}','2025-11-11 07:35:37'),
(1335,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/sales\",\"statusCode\":200,\"duration\":34}','2025-11-11 07:35:37'),
(1336,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:35:42'),
(1337,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:35:42'),
(1338,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":33}','2025-11-11 07:35:42'),
(1339,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:35:42'),
(1340,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:35:54'),
(1341,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:36:01'),
(1342,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:36:01'),
(1343,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":35}','2025-11-11 07:38:11'),
(1344,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":42}','2025-11-11 07:38:11'),
(1345,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:38:28'),
(1346,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:38:28'),
(1347,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":30}','2025-11-11 07:38:28'),
(1348,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":114}','2025-11-11 07:38:28'),
(1349,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":71}','2025-11-11 07:38:29'),
(1350,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":95}','2025-11-11 07:38:29'),
(1351,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":76}','2025-11-11 07:38:29'),
(1352,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:38:29'),
(1353,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:39:10'),
(1354,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:39:10'),
(1355,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":33}','2025-11-11 07:39:10'),
(1356,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":46}','2025-11-11 07:39:10'),
(1357,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:39:10'),
(1358,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:39:10'),
(1359,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":26}','2025-11-11 07:39:10'),
(1360,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:39:10'),
(1361,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:39:18'),
(1362,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":36}','2025-11-11 07:39:18'),
(1363,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:39:25'),
(1364,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:42:01'),
(1365,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:42:01'),
(1366,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":24}','2025-11-11 07:42:01'),
(1367,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:42:01'),
(1368,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:42:01'),
(1369,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":52}','2025-11-11 07:42:01'),
(1370,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":47}','2025-11-11 07:42:02'),
(1371,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":47}','2025-11-11 07:42:02'),
(1372,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:42:49'),
(1373,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:43:02'),
(1374,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:43:02'),
(1375,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":27}','2025-11-11 07:43:02'),
(1376,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":27}','2025-11-11 07:43:02'),
(1377,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:43:02'),
(1378,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:43:02'),
(1379,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:43:02'),
(1380,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:43:02'),
(1381,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:43:04'),
(1382,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":24}','2025-11-11 07:43:04'),
(1383,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":26}','2025-11-11 07:43:05'),
(1384,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:43:53'),
(1385,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:43:53'),
(1386,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:43:53'),
(1387,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":32}','2025-11-11 07:43:53'),
(1388,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:43:53'),
(1389,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":42}','2025-11-11 07:43:53'),
(1390,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:43:53'),
(1391,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:43:53'),
(1392,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":36}','2025-11-11 07:44:07'),
(1393,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:45:02'),
(1394,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:45:02'),
(1395,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":27}','2025-11-11 07:45:02'),
(1396,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:45:02'),
(1397,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:45:02'),
(1398,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:45:02'),
(1399,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":22}','2025-11-11 07:45:03'),
(1400,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":50}','2025-11-11 07:45:03'),
(1401,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":23}','2025-11-11 07:45:31'),
(1402,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:45:47'),
(1403,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:47:15'),
(1404,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:47:15'),
(1405,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":23}','2025-11-11 07:47:15'),
(1406,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":23}','2025-11-11 07:47:15'),
(1407,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":36}','2025-11-11 07:47:15'),
(1408,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":28}','2025-11-11 07:47:16'),
(1409,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:47:16'),
(1410,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:47:16'),
(1411,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:48:04'),
(1412,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:48:04'),
(1413,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":34}','2025-11-11 07:48:04'),
(1414,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:48:05'),
(1415,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:48:05'),
(1416,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:48:05'),
(1417,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:48:05'),
(1418,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":66}','2025-11-11 07:48:05'),
(1419,NULL,'CREATE','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','failure','Route not found','{\"method\":\"POST\",\"path\":\"/api/api/uploads/product-image\",\"statusCode\":404,\"duration\":1}','2025-11-11 07:49:01'),
(1420,NULL,'CREATE','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','failure','Route not found','{\"method\":\"POST\",\"path\":\"/api/api/uploads/product-image\",\"statusCode\":404,\"duration\":1}','2025-11-11 07:49:08'),
(1421,NULL,'CREATE','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','failure','Route not found','{\"method\":\"POST\",\"path\":\"/api/api/uploads/product-image\",\"statusCode\":404,\"duration\":0}','2025-11-11 07:49:22'),
(1422,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:50:19'),
(1423,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:50:19'),
(1424,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:50:19'),
(1425,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:50:19'),
(1426,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:50:19'),
(1427,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:50:19'),
(1428,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:50:19'),
(1429,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:50:19'),
(1430,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"Product image uploaded successfully\",\"imagePath\":\"products/photo_2025-03-21_16-17-57-1762847427548-733776697.jpg\",\"imageUrl\":\"/uploads/products/photo_2025-03-21_16-17-57-1762847427548-733776697.jpg\",\"product\":{\"id\":1,\"name\":\"Love Story\",\"image\":\"products/photo_2025-03-21_16-17-57-1762847427548-733776697.jpg\"}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/uploads/product-image\",\"statusCode\":200,\"duration\":30}','2025-11-11 07:50:27'),
(1431,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:50:27'),
(1432,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"Product image uploaded successfully\",\"imagePath\":\"products/photo_2025-03-21_16-17-57-1762847433564-480513739.jpg\",\"imageUrl\":\"/uploads/products/photo_2025-03-21_16-17-57-1762847433564-480513739.jpg\",\"product\":{\"id\":1,\"name\":\"Love Story\",\"image\":\"products/photo_2025-03-21_16-17-57-1762847433564-480513739.jpg\"}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/uploads/product-image\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:50:33'),
(1433,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":9}','2025-11-11 07:50:33'),
(1434,NULL,'UPDATE','Product',1,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','failure','Validation error','{\"method\":\"PUT\",\"path\":\"/api/products/1\",\"statusCode\":400,\"duration\":6}','2025-11-11 07:50:36'),
(1435,NULL,'UPDATE','Product',1,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','failure','Validation error','{\"method\":\"PUT\",\"path\":\"/api/products/1\",\"statusCode\":400,\"duration\":3}','2025-11-11 07:50:37'),
(1436,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:51:45'),
(1437,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:51:46'),
(1438,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 07:51:46'),
(1439,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:51:46'),
(1440,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:51:46'),
(1441,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":21}','2025-11-11 07:51:46'),
(1442,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:51:46'),
(1443,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:51:46'),
(1444,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":10}','2025-11-11 07:52:26'),
(1445,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:52:26'),
(1446,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":26}','2025-11-11 07:52:26'),
(1447,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":19}','2025-11-11 07:52:26'),
(1448,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:52:26'),
(1449,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:52:26'),
(1450,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":24}','2025-11-11 07:52:27'),
(1451,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":29}','2025-11-11 07:52:27'),
(1452,NULL,'DELETE','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','failure','Cannot delete file that is currently in use','{\"method\":\"DELETE\",\"path\":\"/api/uploads/file\",\"statusCode\":400,\"duration\":9}','2025-11-11 07:52:33'),
(1453,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:53:11'),
(1454,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:53:11'),
(1455,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":20}','2025-11-11 07:53:11'),
(1456,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:53:11'),
(1457,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:53:11'),
(1458,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:53:11'),
(1459,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:53:11'),
(1460,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":16}','2025-11-11 07:53:11'),
(1461,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:53:17'),
(1462,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:53:17'),
(1463,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:53:26'),
(1464,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/sales/products/available\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:53:29'),
(1465,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":39}','2025-11-11 07:53:48'),
(1466,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":38}','2025-11-11 07:53:48'),
(1467,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:53:51'),
(1468,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:53:51'),
(1469,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:53:51'),
(1470,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:53:51'),
(1471,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:53:52'),
(1472,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":3}','2025-11-11 07:53:54'),
(1473,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":7}','2025-11-11 07:53:55'),
(1474,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:53:55'),
(1475,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":14}','2025-11-11 07:53:56'),
(1476,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:53:56'),
(1477,NULL,'VIEW','PurchaseOrder',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/purchase-orders\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:53:56'),
(1478,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":18}','2025-11-11 07:53:56'),
(1479,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:53:57'),
(1480,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":17}','2025-11-11 07:54:10'),
(1481,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":36}','2025-11-11 07:54:10'),
(1482,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:54:14'),
(1483,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"Image uploaded successfully\",\"imagePath\":\"products/photo_2025-03-21_16-17-57-1762847661955-557866729.jpg\",\"imageUrl\":\"/uploads/products/photo_2025-03-21_16-17-57-1762847661955-557866729.jpg\"}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/uploads/product-image\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:54:21'),
(1484,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:55:01'),
(1485,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/profile\",\"statusCode\":200,\"duration\":5}','2025-11-11 07:55:01'),
(1486,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 07:55:01'),
(1487,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 07:55:01'),
(1488,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 07:55:01'),
(1489,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:55:01'),
(1490,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:55:01'),
(1491,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 07:55:01'),
(1492,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":6}','2025-11-11 07:55:03'),
(1493,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/sales/products/available\",\"statusCode\":200,\"duration\":4}','2025-11-11 07:55:06'),
(1494,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":21}','2025-11-11 08:01:57'),
(1495,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":27}','2025-11-11 08:01:57'),
(1496,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":35}','2025-11-11 08:01:57'),
(1497,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":35}','2025-11-11 08:01:57'),
(1498,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":5}','2025-11-11 08:01:57'),
(1499,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":16}','2025-11-11 08:01:57'),
(1500,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":31}','2025-11-11 08:02:16'),
(1501,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":26}','2025-11-11 08:02:16'),
(1502,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','error','Failed to fetch audit statistics','{\"method\":\"GET\",\"path\":\"/api/audit-logs/stats/summary\",\"statusCode\":500,\"duration\":52}','2025-11-11 08:02:16'),
(1503,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/audit-logs\",\"statusCode\":200,\"duration\":29}','2025-11-11 08:02:16'),
(1504,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','error','Failed to fetch audit statistics','{\"method\":\"GET\",\"path\":\"/api/audit-logs/stats/summary\",\"statusCode\":500,\"duration\":18}','2025-11-11 08:02:18'),
(1505,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 08:02:18'),
(1506,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 08:02:18'),
(1507,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":15}','2025-11-11 08:02:18'),
(1508,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 08:02:18'),
(1509,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":10}','2025-11-11 08:02:18'),
(1510,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":15}','2025-11-11 08:02:18'),
(1511,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":16}','2025-11-11 08:02:18'),
(1512,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":31}','2025-11-11 08:02:22'),
(1513,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/role/admin\",\"statusCode\":200,\"duration\":19}','2025-11-11 08:02:24'),
(1514,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/user/3\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:02:32'),
(1515,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":46}','2025-11-11 08:03:14'),
(1516,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":45}','2025-11-11 08:03:14'),
(1517,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":21}','2025-11-11 08:06:19'),
(1518,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":20}','2025-11-11 08:08:19'),
(1519,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":16}','2025-11-11 08:08:20'),
(1520,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 08:08:20'),
(1521,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:08:20'),
(1522,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":18}','2025-11-11 08:08:20'),
(1523,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":18}','2025-11-11 08:08:20'),
(1524,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":21}','2025-11-11 08:08:20'),
(1525,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":7}','2025-11-11 08:08:26'),
(1526,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":5}','2025-11-11 08:08:26'),
(1527,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":5}','2025-11-11 08:08:26'),
(1528,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":11}','2025-11-11 08:08:26'),
(1529,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:08:31'),
(1530,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/reports/stock\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:08:31'),
(1531,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":19}','2025-11-11 08:08:31'),
(1532,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":32}','2025-11-11 08:08:31'),
(1533,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:08:33'),
(1534,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":25}','2025-11-11 08:08:33'),
(1535,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":19}','2025-11-11 08:08:33'),
(1536,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":28}','2025-11-11 08:08:33'),
(1537,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":5}','2025-11-11 08:08:34'),
(1538,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users/stats/overview\",\"statusCode\":200,\"duration\":15}','2025-11-11 08:08:34'),
(1539,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":13}','2025-11-11 08:08:36'),
(1540,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:08:36'),
(1541,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":18}','2025-11-11 08:08:36'),
(1542,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":29}','2025-11-11 08:08:36'),
(1543,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":4}','2025-11-11 08:08:38'),
(1544,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":4}','2025-11-11 08:08:38'),
(1545,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":8}','2025-11-11 08:08:38'),
(1546,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":5}','2025-11-11 08:08:38'),
(1547,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":3}','2025-11-11 08:08:39'),
(1548,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":4}','2025-11-11 08:08:39'),
(1549,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock\",\"statusCode\":200,\"duration\":15}','2025-11-11 08:08:50'),
(1550,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":31}','2025-11-11 08:08:50'),
(1551,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":16}','2025-11-11 08:08:50'),
(1552,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/stock/alerts/low-stock\",\"statusCode\":200,\"duration\":9}','2025-11-11 08:08:50'),
(1553,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":8}','2025-11-11 08:08:50'),
(1554,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:08:51'),
(1555,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":27}','2025-11-11 08:08:52'),
(1556,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":22}','2025-11-11 08:23:07'),
(1557,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":22}','2025-11-11 08:23:07'),
(1558,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":24}','2025-11-11 08:23:07'),
(1559,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":32}','2025-11-11 08:23:07'),
(1560,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/reports/stock\",\"statusCode\":200,\"duration\":19}','2025-11-11 08:23:13'),
(1561,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":20}','2025-11-11 08:23:13'),
(1562,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":25}','2025-11-11 08:23:13'),
(1563,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":21}','2025-11-11 08:23:13'),
(1564,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":13}','2025-11-11 08:23:14'),
(1565,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:23:14'),
(1566,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:23:14'),
(1567,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":29}','2025-11-11 08:23:14'),
(1568,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":14}','2025-11-11 08:23:15'),
(1569,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/reports/stock\",\"statusCode\":200,\"duration\":16}','2025-11-11 08:23:15'),
(1570,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":19}','2025-11-11 08:23:15'),
(1571,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":19}','2025-11-11 08:23:15'),
(1572,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":15}','2025-11-11 08:23:19'),
(1573,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:23:19'),
(1574,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":21}','2025-11-11 08:23:19'),
(1575,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":23}','2025-11-11 08:23:19'),
(1576,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":4}','2025-11-11 08:23:22'),
(1577,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/sales/products/available\",\"statusCode\":200,\"duration\":6}','2025-11-11 08:23:26'),
(1578,NULL,'CREATE','Sale',NULL,'{\"created\":{\"message\":\"Sale transaction completed successfully\",\"sale\":{\"id\":1,\"saleNumber\":\"SALE-20251111-0001\",\"warehouseId\":1,\"saleDate\":\"2025-11-11T08:23:49.000Z\",\"status\":\"completed\",\"subtotal\":\"10.00\",\"taxAmount\":\"0.00\",\"discountAmount\":\"0.00\",\"totalAmount\":\"10.00\",\"paymentMethod\":\"cash\",\"paymentAmount\":\"10.00\",\"changeAmount\":\"0.00\",\"customerName\":\"heng\",\"customerEmail\":\"as@as.as\",\"customerPhone\":\"123456789\",\"notes\":\"sample\",\"soldBy\":3,\"voidedBy\":null,\"voidedAt\":null,\"voidReason\":null,\"createdAt\":\"2025-11-11T08:23:49.000Z\",\"updatedAt\":\"2025-11-11T08:23:49.000Z\",\"Warehouse\":{\"id\":1,\"name\":\"Main Warehouse\",\"code\":\"MAIN\"},\"seller\":{\"id\":3,\"firstName\":\"System\",\"lastName\":\"Administrator\",\"email\":\"admin@example.com\"},\"SaleItems\":[{\"id\":1,\"saleId\":1,\"productId\":1,\"quantity\":1,\"unitPrice\":\"10.00\",\"discount\":\"0.00\",\"totalPrice\":\"10.00\",\"createdAt\":\"2025-11-11T08:23:49.000Z\",\"updatedAt\":\"2025-11-11T08:23:49.000Z\",\"Product\":{\"id\":1,\"name\":\"Love Story\",\"sku\":\"PROD-SKU-000001\",\"unit\":\"pcs\"}}]}}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/sales\",\"statusCode\":201,\"duration\":36}','2025-11-11 08:23:49'),
(1579,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/sales/products/available\",\"statusCode\":200,\"duration\":5}','2025-11-11 08:23:49'),
(1580,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','failure','Sale not found','{\"method\":\"GET\",\"path\":\"/api/sales/daily-summary\",\"statusCode\":404,\"duration\":5}','2025-11-11 08:23:49'),
(1581,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','failure','Sale not found','{\"method\":\"GET\",\"path\":\"/api/sales/daily-summary\",\"statusCode\":404,\"duration\":5}','2025-11-11 08:23:50'),
(1582,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/barcodes/products\",\"statusCode\":200,\"duration\":6}','2025-11-11 08:23:53'),
(1583,NULL,'VIEW','Stock',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/reports/stock\",\"statusCode\":200,\"duration\":21}','2025-11-11 08:23:54'),
(1584,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":21}','2025-11-11 08:23:54'),
(1585,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":23}','2025-11-11 08:23:54'),
(1586,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/suppliers\",\"statusCode\":200,\"duration\":23}','2025-11-11 08:23:54'),
(1587,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/reports/movements\",\"statusCode\":200,\"duration\":9}','2025-11-11 08:24:03'),
(1588,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/reports/low-stock\",\"statusCode\":200,\"duration\":5}','2025-11-11 08:24:09'),
(1589,NULL,'VIEW','PurchaseOrder',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/reports/purchase-orders\",\"statusCode\":200,\"duration\":13}','2025-11-11 08:24:11'),
(1590,NULL,'VIEW','Supplier',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/reports/suppliers\",\"statusCode\":200,\"duration\":22}','2025-11-11 08:24:12'),
(1591,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/reports/inventory-value\",\"statusCode\":200,\"duration\":5}','2025-11-11 08:24:13'),
(1592,NULL,'VIEW','Warehouse',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/warehouses\",\"statusCode\":200,\"duration\":5}','2025-11-11 08:24:14'),
(1593,NULL,'VIEW','Category',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/categories\",\"statusCode\":200,\"duration\":3}','2025-11-11 08:24:14'),
(1594,NULL,'VIEW','Sale',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/analytics/sales-trends\",\"statusCode\":200,\"duration\":25}','2025-11-11 08:24:14'),
(1595,NULL,'VIEW','Product',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/products\",\"statusCode\":200,\"duration\":15}','2025-11-11 08:24:14'),
(1596,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":18}','2025-11-11 08:24:38'),
(1597,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 08:24:38'),
(1598,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 08:24:38'),
(1599,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":13}','2025-11-11 08:24:38'),
(1600,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":18}','2025-11-11 08:24:38'),
(1601,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:24:38'),
(1602,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:24:38'),
(1603,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":5}','2025-11-11 08:24:39'),
(1604,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users/stats/overview\",\"statusCode\":200,\"duration\":16}','2025-11-11 08:24:39'),
(1605,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":7}','2025-11-11 08:24:39'),
(1606,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":12}','2025-11-11 08:24:39'),
(1607,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":11}','2025-11-11 08:24:39'),
(1608,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 08:24:39'),
(1609,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/roles\",\"statusCode\":200,\"duration\":11}','2025-11-11 08:24:39'),
(1610,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions\",\"statusCode\":200,\"duration\":11}','2025-11-11 08:24:40'),
(1611,NULL,'VIEW','User',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/users\",\"statusCode\":200,\"duration\":11}','2025-11-11 08:24:40'),
(1612,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":8}','2025-11-11 08:24:40'),
(1613,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":6}','2025-11-11 08:24:40'),
(1614,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/audit-logs\",\"statusCode\":200,\"duration\":14}','2025-11-11 08:24:40'),
(1615,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','error','Failed to fetch audit statistics','{\"method\":\"GET\",\"path\":\"/api/audit-logs/stats/summary\",\"statusCode\":500,\"duration\":22}','2025-11-11 08:24:40'),
(1616,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','error','Failed to fetch audit statistics','{\"method\":\"GET\",\"path\":\"/api/audit-logs/stats/summary\",\"statusCode\":500,\"duration\":17}','2025-11-11 08:24:42'),
(1617,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":10}','2025-11-11 08:24:49'),
(1618,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/auth/permissions/me\",\"statusCode\":200,\"duration\":9}','2025-11-11 08:24:49'),
(1619,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":4}','2025-11-11 08:24:49'),
(1620,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":4}','2025-11-11 08:24:49'),
(1621,3,'CREATE_BACKUP','Database',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"filename\":\"inventory_2025-11-11T08-24-55.sql.gz\",\"size\":27096}','2025-11-11 08:24:55'),
(1622,NULL,'CREATE','Unknown',NULL,'{\"created\":{\"message\":\"Backup created successfully\",\"success\":true,\"filename\":\"inventory_2025-11-11T08-24-55.sql.gz\",\"path\":\"D:\\\\Project\\\\Inventory\\\\backups\\\\inventory_2025-11-11T08-24-55.sql.gz\",\"size\":27096,\"sizeFormatted\":\"26.46 KB\",\"timestamp\":\"2025-11-11T08:24:55.532Z\",\"method\":\"sequelize\"}}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"POST\",\"path\":\"/api/backup/create\",\"statusCode\":200,\"duration\":243}','2025-11-11 08:24:55'),
(1623,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":4}','2025-11-11 08:24:55'),
(1624,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":4}','2025-11-11 08:24:55'),
(1625,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":8}','2025-11-11 08:25:25'),
(1626,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":5}','2025-11-11 08:25:55'),
(1627,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":6}','2025-11-11 08:25:55'),
(1628,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":11}','2025-11-11 08:26:26'),
(1629,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:26:56'),
(1630,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":3}','2025-11-11 08:26:56'),
(1631,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":10}','2025-11-11 08:27:26'),
(1632,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":10}','2025-11-11 08:27:56'),
(1633,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":3}','2025-11-11 08:27:56'),
(1634,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":7}','2025-11-11 08:28:26'),
(1635,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":23}','2025-11-11 08:28:56'),
(1636,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":3}','2025-11-11 08:28:56'),
(1637,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":17}','2025-11-11 08:29:26'),
(1638,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":13}','2025-11-11 08:29:56'),
(1639,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":8}','2025-11-11 08:29:56'),
(1640,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":8}','2025-11-11 08:30:27'),
(1641,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/stats\",\"statusCode\":200,\"duration\":8}','2025-11-11 08:30:56'),
(1642,NULL,'VIEW','Unknown',NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','success',NULL,'{\"method\":\"GET\",\"path\":\"/api/backup/list\",\"statusCode\":200,\"duration\":4}','2025-11-11 08:30:57');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `description`, `parent_id`, `is_active`, `created_at`, `updated_at`) VALUES (1,'Electronics','Electronic devices and components',NULL,1,'2025-11-11 02:07:26','2025-11-11 02:07:26'),
(2,'Clothing','Apparel and fashion items',NULL,1,'2025-11-11 02:07:26','2025-11-11 02:07:26'),
(3,'Food & Beverages','Food items and drinks',NULL,1,'2025-11-11 02:07:26','2025-11-11 02:07:26'),
(4,'Books','Books and publications',NULL,1,'2025-11-11 02:07:26','2025-11-11 02:07:26'),
(5,'Home & Garden','Home improvement and garden supplies',NULL,1,'2025-11-11 02:07:26','2025-11-11 02:07:26');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(100) DEFAULT NULL COMMENT 'Legacy permission key (e.g., VIEW_PRODUCTS, CREATE_PRODUCTS) - kept for backward compatibility',
  `name` varchar(100) NOT NULL COMMENT 'Resource name for CRUD permissions (e.g., products, stock, categories)',
  `display_name` varchar(200) NOT NULL COMMENT 'Human-readable permission name (e.g., Products, Stock Management)',
  `description` text DEFAULT NULL COMMENT 'Detailed description of what this permission allows',
  `category` varchar(50) DEFAULT NULL COMMENT 'Permission category (e.g., products, stock, users)',
  `is_active` tinyint(1) DEFAULT 1 COMMENT 'Whether this permission is active and can be assigned',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `name_2` (`name`),
  UNIQUE KEY `name_3` (`name`),
  UNIQUE KEY `name_4` (`name`),
  UNIQUE KEY `key` (`key`),
  UNIQUE KEY `key_2` (`key`),
  UNIQUE KEY `key_3` (`key`),
  UNIQUE KEY `key_4` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `key`, `name`, `display_name`, `description`, `category`, `is_active`, `created_at`, `updated_at`) VALUES (14,NULL,'dashboard','Dashboard','Access to view the main dashboard','dashboard',1,'2025-11-11 02:07:24','2025-11-11 02:07:24'),
(15,NULL,'products','Products','Product management','inventory',1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(16,NULL,'stock','Stock Management','Stock/inventory management','inventory',1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(17,NULL,'categories','Categories','Category management','inventory',1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(18,NULL,'suppliers','Suppliers','Supplier management','inventory',1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(19,NULL,'warehouses','Warehouses','Warehouse management','inventory',1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(20,NULL,'purchase_orders','Purchase Orders','Purchase order management','inventory',1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(21,NULL,'pos','Point of Sale','Point of Sale system','sales',1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(22,NULL,'reports','Reports','Reports access','reports',1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(23,NULL,'analytics','Analytics','Analytics access','reports',1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(24,NULL,'users','Users','User management','management',1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(25,NULL,'barcodes','Barcodes','Barcode management','inventory',1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(26,NULL,'search','Search','Search functionality','system',1,'2025-11-11 02:07:25','2025-11-11 02:07:25');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sku` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `cost_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `unit` varchar(20) NOT NULL DEFAULT 'pcs',
  `barcode` varchar(100) DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `min_stock_level` int(11) DEFAULT 0,
  `max_stock_level` int(11) DEFAULT 1000,
  `reorder_point` int(11) DEFAULT 10,
  `expiry_date` datetime DEFAULT NULL,
  `is_perishable` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `image` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku` (`sku`),
  UNIQUE KEY `barcode` (`barcode`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`id`, `sku`, `name`, `description`, `category_id`, `unit_price`, `cost_price`, `unit`, `barcode`, `qr_code`, `min_stock_level`, `max_stock_level`, `reorder_point`, `expiry_date`, `is_perishable`, `is_active`, `image`, `created_at`, `updated_at`) VALUES (1,'PROD-SKU-000001','Love Story','sample',4,10.00,1000.00,'pcs',NULL,NULL,999,10000,9,NULL,0,1,'products/log_location-1761208726306-485910795.png','2025-11-11 07:32:03','2025-11-11 07:50:33');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_items`
--

DROP TABLE IF EXISTS `purchase_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `received_quantity` int(11) DEFAULT 0,
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(12,2) NOT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `batch_number` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_id` (`purchase_order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `purchase_order_items_ibfk_1` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purchase_order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_items`
--

LOCK TABLES `purchase_order_items` WRITE;
/*!40000 ALTER TABLE `purchase_order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `order_date` datetime NOT NULL,
  `expected_delivery_date` datetime DEFAULT NULL,
  `actual_delivery_date` datetime DEFAULT NULL,
  `status` enum('draft','pending','approved','ordered','received','cancelled') NOT NULL DEFAULT 'draft',
  `total_amount` decimal(12,2) DEFAULT 0.00,
  `tax_amount` decimal(12,2) DEFAULT 0.00,
  `discount_amount` decimal(12,2) DEFAULT 0.00,
  `final_amount` decimal(12,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `supplier_id` (`supplier_id`),
  KEY `warehouse_id` (`warehouse_id`),
  KEY `created_by` (`created_by`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `purchase_orders_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purchase_orders_ibfk_2` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purchase_orders_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `purchase_orders_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_orders`
--

LOCK TABLES `purchase_orders` WRITE;
/*!40000 ALTER TABLE `purchase_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` enum('admin','inventory_manager','sales_staff','auditor') DEFAULT NULL COMMENT 'Legacy role ENUM - kept for backward compatibility during migration',
  `role_id` int(11) DEFAULT NULL COMMENT 'Foreign key to roles table',
  `permission_id` int(11) NOT NULL COMMENT 'Foreign key to permissions table',
  `can_create` tinyint(1) DEFAULT 0 COMMENT 'Can create resource (CRUD flag)',
  `can_read` tinyint(1) DEFAULT 0 COMMENT 'Can read/view resource (CRUD flag)',
  `can_update` tinyint(1) DEFAULT 0 COMMENT 'Can update/edit resource (CRUD flag)',
  `can_delete` tinyint(1) DEFAULT 0 COMMENT 'Can delete resource (CRUD flag)',
  `granted` tinyint(1) DEFAULT 1 COMMENT 'Legacy granted flag - kept for backward compatibility during migration',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_role_id_permission` (`role_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `role_permissions_ibfk_7` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `role_permissions_ibfk_8` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` (`id`, `role`, `role_id`, `permission_id`, `can_create`, `can_read`, `can_update`, `can_delete`, `granted`, `created_at`, `updated_at`) VALUES (14,NULL,5,14,1,1,1,1,1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(15,NULL,5,15,1,1,1,1,1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(16,NULL,5,16,1,1,1,1,1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(17,NULL,5,17,1,1,1,1,1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(18,NULL,5,18,1,1,1,1,1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(19,NULL,5,19,1,1,1,1,1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(20,NULL,5,20,1,1,1,1,1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(21,NULL,5,21,1,1,1,1,1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(22,NULL,5,22,1,1,1,1,1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(23,NULL,5,23,1,0,1,1,1,'2025-11-11 02:07:25','2025-11-11 07:08:36'),
(24,NULL,5,24,1,1,1,1,1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(25,NULL,5,25,1,1,1,1,1,'2025-11-11 02:07:25','2025-11-11 02:07:25'),
(27,NULL,7,14,1,0,0,0,1,'2025-11-11 06:59:55','2025-11-11 07:11:52'),
(28,NULL,7,15,1,1,0,0,1,'2025-11-11 07:14:27','2025-11-11 07:16:06');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT 'Unique role name (e.g., admin, inventory_manager, sales_staff, auditor)',
  `display_name` varchar(100) NOT NULL COMMENT 'Human-readable role name (e.g., Administrator, Inventory Manager)',
  `description` text DEFAULT NULL COMMENT 'Description of the role and its responsibilities',
  `is_active` tinyint(1) DEFAULT 1 COMMENT 'Whether this role is active and can be assigned',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `name_2` (`name`),
  UNIQUE KEY `name_3` (`name`),
  UNIQUE KEY `name_4` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `is_active`, `created_at`, `updated_at`) VALUES (5,'admin','Administrator','Full system access with all permissions',1,'2025-11-11 02:07:24','2025-11-11 02:07:24'),
(6,'inventory_manager','Inventory Manager','Manages inventory, products, stock, and purchase orders',1,'2025-11-11 02:07:24','2025-11-11 02:07:24'),
(7,'sales_staff','Sales Staff','Handles point of sale and sales transactions',1,'2025-11-11 02:07:24','2025-11-11 02:07:24'),
(8,'auditor','Auditor','Read-only access for auditing and reporting',1,'2025-11-11 02:07:24','2025-11-11 02:07:24');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale_items`
--

DROP TABLE IF EXISTS `sale_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) DEFAULT 0.00,
  `total_price` decimal(12,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_items`
--

LOCK TABLES `sale_items` WRITE;
/*!40000 ALTER TABLE `sale_items` DISABLE KEYS */;
INSERT INTO `sale_items` (`id`, `sale_id`, `product_id`, `quantity`, `unit_price`, `discount`, `total_price`, `created_at`, `updated_at`) VALUES (1,1,1,1,10.00,0.00,10.00,'2025-11-11 08:23:49','2025-11-11 08:23:49');
/*!40000 ALTER TABLE `sale_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_number` varchar(50) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `sale_date` datetime NOT NULL,
  `status` enum('completed','void','refunded') NOT NULL DEFAULT 'completed',
  `subtotal` decimal(12,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(12,2) DEFAULT 0.00,
  `discount_amount` decimal(12,2) DEFAULT 0.00,
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_method` enum('cash','card','other') NOT NULL DEFAULT 'cash',
  `payment_amount` decimal(12,2) NOT NULL,
  `change_amount` decimal(12,2) DEFAULT 0.00,
  `customer_name` varchar(200) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `sold_by` int(11) NOT NULL,
  `voided_by` int(11) DEFAULT NULL,
  `voided_at` datetime DEFAULT NULL,
  `void_reason` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sale_number` (`sale_number`),
  KEY `warehouse_id` (`warehouse_id`),
  KEY `sold_by` (`sold_by`),
  KEY `voided_by` (`voided_by`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`sold_by`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `sales_ibfk_3` FOREIGN KEY (`voided_by`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` (`id`, `sale_number`, `warehouse_id`, `sale_date`, `status`, `subtotal`, `tax_amount`, `discount_amount`, `total_amount`, `payment_method`, `payment_amount`, `change_amount`, `customer_name`, `customer_email`, `customer_phone`, `notes`, `sold_by`, `voided_by`, `voided_at`, `void_reason`, `created_at`, `updated_at`) VALUES (1,'SALE-20251111-0001',1,'2025-11-11 08:23:49','completed',10.00,0.00,0.00,10.00,'cash',10.00,0.00,'heng','as@as.as','123456789','sample',3,NULL,NULL,NULL,'2025-11-11 08:23:49','2025-11-11 08:23:49');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_movements`
--

DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `type` enum('in','out','transfer','adjustment','return') NOT NULL,
  `quantity` int(11) NOT NULL,
  `previous_quantity` int(11) NOT NULL,
  `new_quantity` int(11) NOT NULL,
  `reference_type` enum('purchase','sale','transfer','adjustment','return','waste') DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL COMMENT 'ID of the related record (purchase order, sale, etc.)',
  `reason` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `stock_movements_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `stock_movements_ibfk_2` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `stock_movements_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_movements`
--

LOCK TABLES `stock_movements` WRITE;
/*!40000 ALTER TABLE `stock_movements` DISABLE KEYS */;
INSERT INTO `stock_movements` (`id`, `product_id`, `warehouse_id`, `type`, `quantity`, `previous_quantity`, `new_quantity`, `reference_type`, `reference_id`, `reason`, `notes`, `user_id`, `created_at`, `updated_at`) VALUES (1,1,1,'in',10,0,10,'adjustment',NULL,'sample',NULL,3,'2025-11-11 07:34:37','2025-11-11 07:34:37'),
(2,1,1,'out',1,10,9,'sale',1,'Sale transaction',NULL,3,'2025-11-11 08:23:49','2025-11-11 08:23:49');
/*!40000 ALTER TABLE `stock_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stocks`
--

DROP TABLE IF EXISTS `stocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `reserved_quantity` int(11) DEFAULT 0 COMMENT 'Quantity reserved for pending orders',
  `location` varchar(100) DEFAULT NULL COMMENT 'Specific location within warehouse (shelf, bin, etc.)',
  `expiry_date` datetime DEFAULT NULL,
  `batch_number` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`),
  CONSTRAINT `stocks_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `stocks_ibfk_2` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stocks`
--

LOCK TABLES `stocks` WRITE;
/*!40000 ALTER TABLE `stocks` DISABLE KEYS */;
INSERT INTO `stocks` (`id`, `product_id`, `warehouse_id`, `quantity`, `reserved_quantity`, `location`, `expiry_date`, `batch_number`, `created_at`, `updated_at`) VALUES (1,1,1,9,0,'PP',NULL,NULL,'2025-11-11 07:34:37','2025-11-11 08:23:49');
/*!40000 ALTER TABLE `stocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `zip_code` varchar(10) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `tax_id` varchar(50) DEFAULT NULL,
  `payment_terms` varchar(100) DEFAULT 'Net 30',
  `rating` int(11) DEFAULT 5,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` (`id`, `name`, `contact_person`, `email`, `phone`, `address`, `city`, `state`, `zip_code`, `country`, `tax_id`, `payment_terms`, `rating`, `is_active`, `created_at`, `updated_at`) VALUES (1,'ABC Supply Co.','John Smith','john@abcsupply.com','555-0123','456 Supplier Ave','Supplier City','SC','67890','USA',NULL,'Net 30',5,1,'2025-11-11 02:07:26','2025-11-11 02:07:26');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT 'Foreign key to users table',
  `permission_id` int(11) NOT NULL COMMENT 'Foreign key to permissions table',
  `can_create` tinyint(1) DEFAULT 0 COMMENT 'Can create resource (CRUD flag)',
  `can_read` tinyint(1) DEFAULT 0 COMMENT 'Can read/view resource (CRUD flag)',
  `can_update` tinyint(1) DEFAULT 0 COMMENT 'Can update/edit resource (CRUD flag)',
  `can_delete` tinyint(1) DEFAULT 0 COMMENT 'Can delete resource (CRUD flag)',
  `granted` tinyint(1) DEFAULT 1 COMMENT 'Legacy granted flag - kept for backward compatibility during migration',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_permission` (`user_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `user_permissions_ibfk_7` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_permissions_ibfk_8` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permissions`
--

LOCK TABLES `user_permissions` WRITE;
/*!40000 ALTER TABLE `user_permissions` DISABLE KEYS */;
INSERT INTO `user_permissions` (`id`, `user_id`, `permission_id`, `can_create`, `can_read`, `can_update`, `can_delete`, `granted`, `created_at`, `updated_at`) VALUES (1,4,14,0,1,0,0,1,'2025-11-11 02:18:46','2025-11-11 02:55:03'),
(2,4,25,0,1,0,0,1,'2025-11-11 02:19:28','2025-11-11 02:19:28'),
(3,3,14,0,1,0,0,1,'2025-11-11 02:20:54','2025-11-11 02:40:40'),
(4,4,17,0,1,0,0,1,'2025-11-11 02:58:18','2025-11-11 02:58:18'),
(5,4,15,0,1,0,0,1,'2025-11-11 02:58:21','2025-11-11 02:58:21'),
(6,4,20,0,0,0,0,1,'2025-11-11 06:59:41','2025-11-11 06:59:42'),
(7,3,26,0,1,0,0,1,'2025-11-11 07:16:32','2025-11-11 07:16:37');
/*!40000 ALTER TABLE `user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `role` enum('admin','inventory_manager','sales_staff','auditor') NOT NULL DEFAULT 'sales_staff',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username_2` (`username`),
  UNIQUE KEY `email_2` (`email`),
  UNIQUE KEY `username_3` (`username`),
  UNIQUE KEY `email_3` (`email`),
  UNIQUE KEY `username_4` (`username`),
  UNIQUE KEY `email_4` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `username`, `email`, `password`, `first_name`, `last_name`, `role`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES (3,'admin','admin@example.com','$2a$12$smyMSNHnRS7.2cA/w6dPgOht2smJ.7uPINT3w8m0puj2BXe0UFWTm','System','Administrator','admin',1,'2025-11-11 07:03:05','2025-11-11 02:07:25','2025-11-11 07:03:05'),
(4,'testuser','test@example.com','$2a$12$NNUtlcbr5/ZRhUVXHc5lX.7ap/sE4rPQr5sU1IWpjDvmd7w0cgm8a','Test','User','sales_staff',1,'2025-11-11 02:58:46','2025-11-11 02:07:26','2025-11-11 02:58:46');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warehouses`
--

DROP TABLE IF EXISTS `warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) NOT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `zip_code` varchar(10) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL COMMENT 'Maximum storage capacity',
  `manager_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `manager_id` (`manager_id`),
  CONSTRAINT `warehouses_ibfk_1` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouses`
--

LOCK TABLES `warehouses` WRITE;
/*!40000 ALTER TABLE `warehouses` DISABLE KEYS */;
INSERT INTO `warehouses` (`id`, `name`, `code`, `address`, `city`, `state`, `zip_code`, `country`, `capacity`, `manager_id`, `is_active`, `created_at`, `updated_at`) VALUES (1,'Main Warehouse','MAIN','123 Business St','Business City','BC','12345','USA',NULL,NULL,1,'2025-11-11 02:07:26','2025-11-11 02:07:26');
/*!40000 ALTER TABLE `warehouses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'inventory_db'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetDashboardSummary` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetDashboardSummary`(
    IN p_start_date DATETIME,
    IN p_end_date DATETIME
)
BEGIN
    -- Get basic counts and statistics
    SELECT 
        (SELECT COUNT(*) FROM products WHERE is_active = 1) as total_products,
        (SELECT COUNT(*) FROM suppliers WHERE is_active = 1) as total_suppliers,
        (SELECT COUNT(*) FROM warehouses WHERE is_active = 1) as total_warehouses,
        (SELECT COUNT(*) FROM purchase_orders WHERE order_date BETWEEN p_start_date AND p_end_date) as total_orders,
        (SELECT COUNT(*) FROM stocks s 
         JOIN products p ON s.product_id = p.id 
         WHERE p.is_active = 1 AND s.quantity <= p.reorder_point) as low_stock_count,
        (SELECT COUNT(*) FROM stock_movements WHERE created_at BETWEEN p_start_date AND p_end_date) as recent_movements,
        (SELECT COUNT(*) FROM purchase_orders WHERE status IN ('draft', 'pending', 'approved')) as pending_orders;
    
    -- Get recent low stock alerts (top 5)
    SELECT 
        p.name as product_name,
        p.sku as product_sku,
        w.name as warehouse,
        s.quantity as current_stock,
        p.reorder_point
    FROM stocks s
    JOIN products p ON s.product_id = p.id
    JOIN warehouses w ON s.warehouse_id = w.id
    WHERE p.is_active = 1 AND s.quantity <= p.reorder_point
    ORDER BY s.quantity ASC
    LIMIT 5;
    
    -- Get recent stock movements (top 10)
    SELECT 
        p.name as product_name,
        p.sku as product_sku,
        w.name as warehouse,
        sm.type as movement_type,
        sm.quantity,
        sm.reason,
        sm.created_at as movement_date,
        CONCAT(COALESCE(u.first_name, ''), ' ', COALESCE(u.last_name, '')) as performer
    FROM stock_movements sm
    JOIN products p ON sm.product_id = p.id
    JOIN warehouses w ON sm.warehouse_id = w.id
    LEFT JOIN users u ON sm.user_id = u.id
    WHERE sm.created_at BETWEEN p_start_date AND p_end_date
    ORDER BY sm.created_at DESC
    LIMIT 10;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetInventoryValueReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetInventoryValueReport`(
    IN p_warehouse_id INT,
    IN p_category_id INT,
    IN p_valuation_method VARCHAR(20)
)
BEGIN
    -- Get inventory items with valuation
    SELECT 
        s.id,
        p.id as product_id,
        p.name as product_name,
        p.sku as product_sku,
        COALESCE(c.name, 'Uncategorized') as category,
        w.name as warehouse,
        s.quantity,
        p.cost_price,
        p.unit_price,
        (s.quantity * COALESCE(p.cost_price, 0)) as cost_value,
        (s.quantity * COALESCE(p.unit_price, 0)) as retail_value,
        CASE 
            WHEN p.unit_price > 0 AND p.cost_price > 0 THEN 
                ((p.unit_price - p.cost_price) / p.unit_price) * 100
            ELSE 0 
        END as profit_margin,
        ((s.quantity * COALESCE(p.unit_price, 0)) - (s.quantity * COALESCE(p.cost_price, 0))) as profit_amount
    FROM stocks s
    JOIN products p ON s.product_id = p.id
    LEFT JOIN categories c ON p.category_id = c.id
    JOIN warehouses w ON s.warehouse_id = w.id
    WHERE p.is_active = 1
        AND (p_warehouse_id IS NULL OR s.warehouse_id = p_warehouse_id)
        AND (p_category_id IS NULL OR p.category_id = p_category_id)
    ORDER BY 
        CASE p_valuation_method
            WHEN 'cost' THEN (s.quantity * COALESCE(p.cost_price, 0))
            WHEN 'retail' THEN (s.quantity * COALESCE(p.unit_price, 0))
            ELSE p.name
        END DESC;
    
    -- Get summary statistics
    SELECT 
        COUNT(*) as total_products,
        SUM(s.quantity) as total_quantity,
        SUM(s.quantity * COALESCE(p.cost_price, 0)) as total_cost_value,
        SUM(s.quantity * COALESCE(p.unit_price, 0)) as total_retail_value,
        SUM((s.quantity * COALESCE(p.unit_price, 0)) - (s.quantity * COALESCE(p.cost_price, 0))) as total_profit_amount,
        CASE 
            WHEN COUNT(*) > 0 THEN 
                AVG(CASE 
                    WHEN p.unit_price > 0 AND p.cost_price > 0 THEN 
                        ((p.unit_price - p.cost_price) / p.unit_price) * 100
                    ELSE 0 
                END)
            ELSE 0 
        END as average_profit_margin
    FROM stocks s
    JOIN products p ON s.product_id = p.id
    WHERE p.is_active = 1
        AND (p_warehouse_id IS NULL OR s.warehouse_id = p_warehouse_id)
        AND (p_category_id IS NULL OR p.category_id = p_category_id);
    
    -- Get category summary
    SELECT 
        COALESCE(c.name, 'Uncategorized') as category_name,
        COUNT(*) as count,
        SUM(s.quantity) as quantity,
        SUM(s.quantity * COALESCE(p.cost_price, 0)) as cost_value,
        SUM(s.quantity * COALESCE(p.unit_price, 0)) as retail_value,
        SUM((s.quantity * COALESCE(p.unit_price, 0)) - (s.quantity * COALESCE(p.cost_price, 0))) as profit_amount
    FROM stocks s
    JOIN products p ON s.product_id = p.id
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.is_active = 1
        AND (p_warehouse_id IS NULL OR s.warehouse_id = p_warehouse_id)
        AND (p_category_id IS NULL OR p.category_id = p_category_id)
    GROUP BY c.id, c.name
    ORDER BY category_name;
    
    -- Get warehouse summary
    SELECT 
        w.name as warehouse_name,
        COUNT(*) as count,
        SUM(s.quantity) as quantity,
        SUM(s.quantity * COALESCE(p.cost_price, 0)) as cost_value,
        SUM(s.quantity * COALESCE(p.unit_price, 0)) as retail_value
    FROM stocks s
    JOIN products p ON s.product_id = p.id
    JOIN warehouses w ON s.warehouse_id = w.id
    WHERE p.is_active = 1
        AND (p_warehouse_id IS NULL OR s.warehouse_id = p_warehouse_id)
        AND (p_category_id IS NULL OR p.category_id = p_category_id)
    GROUP BY w.id, w.name
    ORDER BY warehouse_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetLowStockAlertsReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetLowStockAlertsReport`(
    IN p_warehouse_id INT,
    IN p_category_id INT,
    IN p_critical_only BOOLEAN
)
BEGIN
    -- Get low stock alerts with calculations
    SELECT 
        s.product_id,
        p.name as product_name,
        p.sku as product_sku,
        COALESCE(c.name, 'Uncategorized') as category,
        w.name as warehouse,
        s.quantity as current_stock,
        p.reorder_point,
        p.min_stock_level,
        CASE 
            WHEN s.quantity <= p.min_stock_level THEN 1 
            ELSE 0 
        END as is_critical,
        CASE 
            WHEN p.reorder_point > 0 THEN CEIL(s.quantity / (p.reorder_point / 30))
            ELSE 0 
        END as days_until_reorder,
        GREATEST(p.reorder_point * 2 - s.quantity, p.reorder_point) as suggested_order_quantity,
        p.cost_price,
        (GREATEST(p.reorder_point * 2 - s.quantity, p.reorder_point) * COALESCE(p.cost_price, 0)) as estimated_cost
    FROM stocks s
    JOIN products p ON s.product_id = p.id
    LEFT JOIN categories c ON p.category_id = c.id
    JOIN warehouses w ON s.warehouse_id = w.id
    WHERE p.is_active = 1
        AND (p_warehouse_id IS NULL OR s.warehouse_id = p_warehouse_id)
        AND (p_category_id IS NULL OR p.category_id = p_category_id)
        AND (
            (p_critical_only AND s.quantity <= p.min_stock_level) OR
            (NOT p_critical_only AND s.quantity <= p.reorder_point)
        )
    ORDER BY s.quantity ASC;
    
    -- Get summary statistics
    SELECT 
        COUNT(*) as total_alerts,
        SUM(CASE WHEN s.quantity <= p.min_stock_level THEN 1 ELSE 0 END) as critical_alerts,
        SUM((GREATEST(p.reorder_point * 2 - s.quantity, p.reorder_point) * COALESCE(p.cost_price, 0))) as total_estimated_cost,
        CASE 
            WHEN COUNT(*) > 0 THEN AVG(CASE WHEN p.reorder_point > 0 THEN CEIL(s.quantity / (p.reorder_point / 30)) ELSE 0 END)
            ELSE 0 
        END as average_days_until_reorder
    FROM stocks s
    JOIN products p ON s.product_id = p.id
    WHERE p.is_active = 1
        AND (p_warehouse_id IS NULL OR s.warehouse_id = p_warehouse_id)
        AND (p_category_id IS NULL OR p.category_id = p_category_id)
        AND (
            (p_critical_only AND s.quantity <= p.min_stock_level) OR
            (NOT p_critical_only AND s.quantity <= p.reorder_point)
        );
    
    -- Get category alerts summary
    SELECT 
        COALESCE(c.name, 'Uncategorized') as category,
        COUNT(*) as count,
        SUM(CASE WHEN s.quantity <= p.min_stock_level THEN 1 ELSE 0 END) as critical,
        SUM((GREATEST(p.reorder_point * 2 - s.quantity, p.reorder_point) * COALESCE(p.cost_price, 0))) as estimated_cost
    FROM stocks s
    JOIN products p ON s.product_id = p.id
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.is_active = 1
        AND (p_warehouse_id IS NULL OR s.warehouse_id = p_warehouse_id)
        AND (p_category_id IS NULL OR p.category_id = p_category_id)
        AND (
            (p_critical_only AND s.quantity <= p.min_stock_level) OR
            (NOT p_critical_only AND s.quantity <= p.reorder_point)
        )
    GROUP BY c.id, c.name
    ORDER BY category;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetPurchaseOrdersReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetPurchaseOrdersReport`(
    IN p_start_date DATETIME,
    IN p_end_date DATETIME,
    IN p_supplier_id INT,
    IN p_warehouse_id INT,
    IN p_status VARCHAR(20),
    IN p_page INT,
    IN p_limit INT
)
BEGIN
    DECLARE v_offset INT DEFAULT 0;
    SET v_offset = (p_page - 1) * p_limit;
    
    -- Get purchase orders data
    SELECT 
        po.id,
        po.order_number,
        po.order_date,
        po.status,
        po.total_amount,
        po.final_amount,
        s.name as supplier_name,
        w.name as warehouse_name,
        COUNT(poi.id) as item_count,
        SUM(poi.quantity) as total_quantity,
        DATEDIFF(COALESCE(po.actual_delivery_date, NOW()), po.order_date) as days_to_receive
    FROM purchase_orders po
    LEFT JOIN suppliers s ON po.supplier_id = s.id
    LEFT JOIN warehouses w ON po.warehouse_id = w.id
    LEFT JOIN purchase_order_items poi ON po.id = poi.purchase_order_id
    WHERE po.order_date BETWEEN p_start_date AND p_end_date
        AND (p_supplier_id IS NULL OR po.supplier_id = p_supplier_id)
        AND (p_warehouse_id IS NULL OR po.warehouse_id = p_warehouse_id)
        AND (p_status IS NULL OR po.status = p_status)
    GROUP BY po.id, po.order_number, po.order_date, po.status, po.total_amount, po.final_amount, s.name, w.name, po.actual_delivery_date
    ORDER BY po.order_date DESC
    LIMIT p_limit OFFSET v_offset;
    
    -- Get total count
    SELECT COUNT(*) as total_orders
    FROM purchase_orders po
    WHERE po.order_date BETWEEN p_start_date AND p_end_date
        AND (p_supplier_id IS NULL OR po.supplier_id = p_supplier_id)
        AND (p_warehouse_id IS NULL OR po.warehouse_id = p_warehouse_id)
        AND (p_status IS NULL OR po.status = p_status);
    
    -- Get summary statistics
    SELECT 
        COUNT(*) as total_orders,
        SUM(COALESCE(po.final_amount, 0)) as total_value,
        AVG(COALESCE(po.final_amount, 0)) as average_order_value,
        COUNT(CASE WHEN po.status = 'draft' THEN 1 END) as draft_count,
        COUNT(CASE WHEN po.status = 'pending' THEN 1 END) as pending_count,
        COUNT(CASE WHEN po.status = 'approved' THEN 1 END) as approved_count,
        COUNT(CASE WHEN po.status = 'received' THEN 1 END) as received_count,
        COUNT(CASE WHEN po.status = 'cancelled' THEN 1 END) as cancelled_count,
        AVG(CASE WHEN po.actual_delivery_date IS NOT NULL THEN DATEDIFF(po.actual_delivery_date, po.order_date) ELSE NULL END) as avg_days_to_receive
    FROM purchase_orders po
    WHERE po.order_date BETWEEN p_start_date AND p_end_date
        AND (p_supplier_id IS NULL OR po.supplier_id = p_supplier_id)
        AND (p_warehouse_id IS NULL OR po.warehouse_id = p_warehouse_id)
        AND (p_status IS NULL OR po.status = p_status);
    
    -- Get status summary
    SELECT 
        po.status,
        COUNT(*) as count,
        SUM(COALESCE(po.final_amount, 0)) as total_value
    FROM purchase_orders po
    WHERE po.order_date BETWEEN p_start_date AND p_end_date
        AND (p_supplier_id IS NULL OR po.supplier_id = p_supplier_id)
        AND (p_warehouse_id IS NULL OR po.warehouse_id = p_warehouse_id)
        AND (p_status IS NULL OR po.status = p_status)
    GROUP BY po.status;
    
    -- Get supplier summary
    SELECT 
        s.id as supplier_id,
        s.name as supplier_name,
        COUNT(po.id) as order_count,
        SUM(COALESCE(po.final_amount, 0)) as total_value,
        AVG(COALESCE(po.final_amount, 0)) as average_order_value,
        AVG(CASE WHEN po.actual_delivery_date IS NOT NULL THEN DATEDIFF(po.actual_delivery_date, po.order_date) ELSE NULL END) as avg_delivery_days
    FROM purchase_orders po
    JOIN suppliers s ON po.supplier_id = s.id
    WHERE po.order_date BETWEEN p_start_date AND p_end_date
        AND (p_supplier_id IS NULL OR po.supplier_id = p_supplier_id)
        AND (p_warehouse_id IS NULL OR po.warehouse_id = p_warehouse_id)
        AND (p_status IS NULL OR po.status = p_status)
    GROUP BY s.id, s.name
    ORDER BY total_value DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetStockMovementsReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetStockMovementsReport`(
    IN p_start_date DATETIME,
    IN p_end_date DATETIME,
    IN p_product_id INT,
    IN p_warehouse_id INT,
    IN p_movement_type VARCHAR(10),
    IN p_page INT,
    IN p_limit INT
)
BEGIN
    DECLARE v_offset INT DEFAULT 0;
    SET v_offset = (p_page - 1) * p_limit;
    
    -- Get movements data
    SELECT 
        sm.id,
        p.name as product_name,
        p.sku as product_sku,
        w.name as warehouse,
        sm.type as movement_type,
        sm.quantity,
        sm.previous_quantity,
        sm.new_quantity,
        sm.reason,
        sm.notes,
        sm.created_at as movement_date,
        CONCAT(COALESCE(u.first_name, ''), ' ', COALESCE(u.last_name, '')) as performer
    FROM stock_movements sm
    JOIN products p ON sm.product_id = p.id
    JOIN warehouses w ON sm.warehouse_id = w.id
    LEFT JOIN users u ON sm.user_id = u.id
    WHERE sm.created_at BETWEEN p_start_date AND p_end_date
        AND (p_product_id IS NULL OR sm.product_id = p_product_id)
        AND (p_warehouse_id IS NULL OR sm.warehouse_id = p_warehouse_id)
        AND (p_movement_type IS NULL OR sm.type = p_movement_type)
    ORDER BY sm.created_at DESC
    LIMIT p_limit OFFSET v_offset;
    
    -- Get total count
    SELECT COUNT(*) as total_movements
    FROM stock_movements sm
    WHERE sm.created_at BETWEEN p_start_date AND p_end_date
        AND (p_product_id IS NULL OR sm.product_id = p_product_id)
        AND (p_warehouse_id IS NULL OR sm.warehouse_id = p_warehouse_id)
        AND (p_movement_type IS NULL OR sm.type = p_movement_type);
    
    -- Get summary statistics
    SELECT 
        SUM(CASE WHEN type = 'in' THEN quantity ELSE 0 END) as total_in_quantity,
        SUM(CASE WHEN type = 'out' THEN quantity ELSE 0 END) as total_out_quantity,
        SUM(CASE WHEN type = 'in' THEN quantity ELSE -quantity END) as net_quantity
    FROM stock_movements sm
    WHERE sm.created_at BETWEEN p_start_date AND p_end_date
        AND (p_product_id IS NULL OR sm.product_id = p_product_id)
        AND (p_warehouse_id IS NULL OR sm.warehouse_id = p_warehouse_id)
        AND (p_movement_type IS NULL OR sm.type = p_movement_type);
    
    -- Get movement type summary
    SELECT 
        type as movement_type,
        COUNT(*) as count,
        SUM(quantity) as quantity
    FROM stock_movements sm
    WHERE sm.created_at BETWEEN p_start_date AND p_end_date
        AND (p_product_id IS NULL OR sm.product_id = p_product_id)
        AND (p_warehouse_id IS NULL OR sm.warehouse_id = p_warehouse_id)
        AND (p_movement_type IS NULL OR sm.type = p_movement_type)
    GROUP BY type;
    
    -- Get product summary
    SELECT 
        p.name as product_name,
        SUM(CASE WHEN sm.type = 'in' THEN sm.quantity ELSE 0 END) as in_quantity,
        SUM(CASE WHEN sm.type = 'out' THEN sm.quantity ELSE 0 END) as out_quantity,
        SUM(CASE WHEN sm.type = 'in' THEN sm.quantity ELSE -sm.quantity END) as net_quantity
    FROM stock_movements sm
    JOIN products p ON sm.product_id = p.id
    WHERE sm.created_at BETWEEN p_start_date AND p_end_date
        AND (p_product_id IS NULL OR sm.product_id = p_product_id)
        AND (p_warehouse_id IS NULL OR sm.warehouse_id = p_warehouse_id)
        AND (p_movement_type IS NULL OR sm.type = p_movement_type)
    GROUP BY p.id, p.name
    ORDER BY product_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetStockReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetStockReport`(
    IN p_warehouse_id INT,
    IN p_category_id INT,
    IN p_low_stock_only BOOLEAN
)
BEGIN
    -- Get stock data with calculations
    SELECT 
        s.id,
        p.name as product_name,
        p.sku as product_sku,
        COALESCE(c.name, 'Uncategorized') as category,
        w.name as warehouse,
        s.quantity,
        p.reorder_point,
        p.cost_price,
        (s.quantity * COALESCE(p.cost_price, 0)) as total_value,
        s.location,
        CASE 
            WHEN s.quantity <= p.reorder_point THEN 1 
            ELSE 0 
        END as is_low_stock,
        CASE 
            WHEN s.quantity = 0 THEN 1 
            ELSE 0 
        END as is_out_of_stock
    FROM stocks s
    JOIN products p ON s.product_id = p.id
    LEFT JOIN categories c ON p.category_id = c.id
    JOIN warehouses w ON s.warehouse_id = w.id
    WHERE p.is_active = 1
        AND (p_warehouse_id IS NULL OR s.warehouse_id = p_warehouse_id)
        AND (p_category_id IS NULL OR p.category_id = p_category_id)
        AND (NOT p_low_stock_only OR s.quantity <= p.reorder_point)
    ORDER BY s.quantity ASC;
    
    -- Get summary statistics
    SELECT 
        COUNT(*) as total_products,
        SUM(s.quantity) as total_quantity,
        SUM(s.quantity * COALESCE(p.cost_price, 0)) as total_value,
        SUM(CASE WHEN s.quantity <= p.reorder_point THEN 1 ELSE 0 END) as low_stock_count,
        SUM(CASE WHEN s.quantity = 0 THEN 1 ELSE 0 END) as out_of_stock_count,
        CASE 
            WHEN COUNT(*) > 0 THEN SUM(s.quantity) / COUNT(*) 
            ELSE 0 
        END as average_stock_level
    FROM stocks s
    JOIN products p ON s.product_id = p.id
    WHERE p.is_active = 1
        AND (p_warehouse_id IS NULL OR s.warehouse_id = p_warehouse_id)
        AND (p_category_id IS NULL OR p.category_id = p_category_id);
    
    -- Get category summary
    SELECT 
        COALESCE(c.name, 'Uncategorized') as category_name,
        COUNT(*) as count,
        SUM(s.quantity) as quantity,
        SUM(s.quantity * COALESCE(p.cost_price, 0)) as value,
        SUM(CASE WHEN s.quantity <= p.reorder_point THEN 1 ELSE 0 END) as low_stock
    FROM stocks s
    JOIN products p ON s.product_id = p.id
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.is_active = 1
        AND (p_warehouse_id IS NULL OR s.warehouse_id = p_warehouse_id)
        AND (p_category_id IS NULL OR p.category_id = p_category_id)
    GROUP BY c.id, c.name
    ORDER BY category_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetSupplierPerformanceReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_uca1400_ai_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetSupplierPerformanceReport`(
    IN p_start_date DATETIME,
    IN p_end_date DATETIME
)
BEGIN
    -- Get supplier performance data
    SELECT 
        s.id as supplier_id,
        s.name as supplier_name,
        s.email,
        s.phone,
        s.rating,
        COUNT(po.id) as total_orders,
        SUM(COALESCE(po.final_amount, 0)) as total_order_value,
        AVG(COALESCE(po.final_amount, 0)) as average_order_value,
        COUNT(CASE WHEN po.status = 'received' THEN 1 END) as completed_orders,
        COUNT(CASE WHEN po.status = 'cancelled' THEN 1 END) as cancelled_orders,
        AVG(CASE WHEN po.actual_delivery_date IS NOT NULL THEN DATEDIFF(po.actual_delivery_date, po.order_date) ELSE NULL END) as avg_delivery_days,
        COUNT(CASE WHEN po.actual_delivery_date IS NOT NULL AND DATEDIFF(po.actual_delivery_date, po.order_date) <= 7 THEN 1 END) as on_time_deliveries,
        CASE 
            WHEN COUNT(po.id) > 0 THEN 
                (COUNT(CASE WHEN po.actual_delivery_date IS NOT NULL AND DATEDIFF(po.actual_delivery_date, po.order_date) <= 7 THEN 1 END) * 100.0 / COUNT(po.id))
            ELSE 0 
        END as on_time_percentage
    FROM suppliers s
    LEFT JOIN purchase_orders po ON s.id = po.supplier_id 
        AND po.order_date BETWEEN p_start_date AND p_end_date
    WHERE s.is_active = 1
    GROUP BY s.id, s.name, s.email, s.phone, s.rating
    ORDER BY total_order_value DESC;
    
    -- Get summary statistics
    SELECT 
        COUNT(DISTINCT s.id) as total_suppliers,
        COUNT(DISTINCT CASE WHEN po.id IS NOT NULL THEN s.id END) as active_suppliers,
        AVG(s.rating) as average_rating,
        AVG(CASE WHEN po.actual_delivery_date IS NOT NULL THEN DATEDIFF(po.actual_delivery_date, po.order_date) ELSE NULL END) as average_delivery_performance,
        SUM(COALESCE(po.final_amount, 0)) as total_supplier_value
    FROM suppliers s
    LEFT JOIN purchase_orders po ON s.id = po.supplier_id 
        AND po.order_date BETWEEN p_start_date AND p_end_date
    WHERE s.is_active = 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-11-11 15:31:16
